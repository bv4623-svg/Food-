export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers);
  if (options.body && !(options.body instanceof FormData)) headers.set("Content-Type", "application/json");
  const response = await fetch(`/api/v1/${path}`, { ...options, headers, credentials: "same-origin", cache: "no-store" });
  let result;
  try { result = await response.json(); } catch { throw new Error("The server returned an unreadable response. Please retry."); }
  if (!response.ok) throw new Error(result.error?.message ?? "This request could not be completed. Please retry.");
  return result as T;
}
export const write = <T = { message: string }>(path: string, data: unknown = {}, method = "POST", headers?: Record<string, string>) => api<T>(path, { method, body: JSON.stringify(data), headers });
export const number = (value: number) => new Intl.NumberFormat("en-IN").format(value);
export const formatTime = (value: string) => new Date(value).toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" });
export const formatDate = (value: string) => new Date(value).toLocaleDateString("en-IN", { day: "numeric", month: "short" });
export const timeLeft = (value: string) => { const minutes = Math.max(0, Math.floor((+new Date(value) - Date.now()) / 60000)); return minutes === 0 ? "Expired" : minutes < 60 ? `${minutes}m left` : `${Math.floor(minutes / 60)}h ${minutes % 60}m left`; };
export const localDateTime = (date: Date) => new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
export const friendlyStatus = (status: string) => status.toLowerCase().split("_").map((word) => word[0].toUpperCase() + word.slice(1)).join(" ");
