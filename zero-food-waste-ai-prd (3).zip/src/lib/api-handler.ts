import { randomBytes } from "node:crypto";
import { and, eq, gt, isNull, desc, inArray } from "drizzle-orm";
import { z } from "zod";
import sharp from "sharp";
import { db } from "@/db";
import { auditLogs, donations, media, notifications, organizations, passwordResetTokens, reports, reservations, sessions, users } from "@/db/schema";
import { ApiError, assertOrigin, createSession, currentUser, DEMO_ENABLED, digest, endSession, hashPassword, rateLimit, requireUser, verifyPassword } from "@/lib/security";
import { DEMO_USERS, ensureSeed } from "@/lib/seed";
import { aiConfigured, emailConfigured, listingAssistant, sendResetEmail } from "@/lib/integrations";
import { audit, cancelReservation, confirmDelivery, confirmPickup, createDonation, donationInput, getDonation, getImpact, getMatches, getReservations, listDonations, reserveDonation, updateDonation } from "@/lib/workflow";

type Context = { params: Promise<{ path: string[] }> };
const uuid = z.string().uuid();
const email = z.string().trim().email().max(254).transform((v) => v.toLowerCase());
const password = z.string().min(10, "Use at least 10 characters.").max(128).regex(/[a-zA-Z]/, "Include a letter.").regex(/[0-9]/, "Include a number.");
const json = async (request: Request) => { try { if (Number(request.headers.get("content-length") ?? 0) > 100000) throw new ApiError(413, "Request is too large."); return await request.json(); } catch (e) { if (e instanceof ApiError) throw e; throw new ApiError(400, "A valid JSON request body is required."); } };
const ok = (data: unknown, status = 200) => Response.json(data, { status, headers: { "Cache-Control": "no-store" } });

export async function handler(request: Request, context: Context) {
  try {
    const { path } = await context.params;
    const route = path.join("/"), method = request.method, query = new URL(request.url).searchParams;
    if (method !== "GET") assertOrigin(request);
    await ensureSeed();
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
    if (route.startsWith("auth/") && method === "POST") rateLimit(`auth:${ip}:${route}`, route === "auth/demo" ? 60 : 12);
    if (method === "GET" && route === "bootstrap") return ok({ user: await currentUser(), demo: DEMO_ENABLED, aiConfigured: aiConfigured(), emailConfigured: emailConfigured() });
    if (method === "GET" && route === "users/me") return ok(await requireUser());
    if (method === "PATCH" && route === "users/me") {
      const u = await requireUser(); z.object({ status: z.literal("suspended") }).strict().parse(await json(request));
      await db.transaction(async (tx) => {
        if (u.role === "ngo") await tx.select().from(organizations).where(eq(organizations.userId, u.id)).for("update");
        if (u.role === "donor") await tx.select().from(donations).where(eq(donations.donorId, u.organization!.id)).for("update");
        if (u.role !== "admin") {
          const ownership = u.role === "donor" ? eq(donations.donorId, u.organization!.id) : u.role === "ngo" ? eq(reservations.ngoId, u.organization!.id) : eq(reservations.volunteerId, u.id);
          const [active] = await tx.select({ id: reservations.id }).from(reservations).innerJoin(donations, eq(reservations.donationId, donations.id)).where(and(ownership, inArray(reservations.status, ["RESERVED", "PARTIALLY_PICKED_UP", "PICKED_UP", "PARTIALLY_DELIVERED"]))).limit(1);
          if (active) throw new ApiError(409, "Complete or cancel your active reservations before deactivating your account.");
        } else {
          const admins = await tx.select({ id: users.id }).from(users).where(and(eq(users.role, "admin"), eq(users.status, "active"), eq(users.isDemo, u.isDemo)));
          if (admins.length < 2) throw new ApiError(409, "The last active administrator cannot deactivate their account.");
        }
        await tx.update(users).set({ status: "suspended" }).where(eq(users.id, u.id));
        await tx.delete(sessions).where(eq(sessions.userId, u.id));
        await audit(tx, u, "ACCOUNT_DEACTIVATED", "user", u.id);
      });
      await endSession(); return ok({ message: "Your account is deactivated and all sessions invalidated. Historical impact and audit records are retained." });
    }
    if (method === "POST" && route === "reports") {
      const u = await requireUser(); rateLimit(`report:${u.id}`, 5);
      const data = z.object({ donationId: uuid, reason: z.string().trim().min(20).max(2000) }).strict().parse(await json(request));
      await getDonation(data.donationId, u);
      const id = await db.transaction(async (tx) => {
        const [report] = await tx.insert(reports).values({ ...data, reporterId: u.id, isDemo: u.isDemo }).returning();
        await audit(tx, u, "CONCERN_REPORTED", "report", report.id, { donationId: data.donationId });
        const admins = await tx.select({ id: users.id }).from(users).where(and(eq(users.role, "admin"), eq(users.status, "active"), eq(users.isDemo, u.isDemo)));
        for (const a of admins) await tx.insert(notifications).values({ userId: a.id, title: "A concern needs review", message: "A donation concern was submitted. Review it in the admin report queue." });
        return report.id;
      });
      return ok({ id, message: "Your concern is recorded and awaiting human administrator review." }, 201);
    }
    if (method === "POST" && route === "auth/demo") {
      if (!DEMO_ENABLED) throw new ApiError(404, "Demo sign-in is disabled in production.");
      const { role } = z.object({ role: z.enum(["donor", "donor2", "ngo", "ngo2", "volunteer", "admin"]) }).strict().parse(await json(request));
      const [account] = await db.select().from(users).where(and(eq(users.id, DEMO_USERS[role]), eq(users.isDemo, true), eq(users.status, "active")));
      const [org] = account ? await db.select().from(organizations).where(eq(organizations.userId, account.id)) : [];
      if (!account || !org || org.verification !== "verified" || account.role !== role.replace(/2$/, "")) throw new ApiError(403, "This demo account is not eligible to sign in.");
      await createSession(account.id);
      return ok({ user: await currentUser() });
    }
    if (method === "POST" && route === "auth/register") {
      const data = z.object({ email, password, name: z.string().trim().min(2).max(100), role: z.enum(["donor", "ngo", "volunteer"]), organizationName: z.string().trim().min(2).max(150), address: z.string().trim().min(3).max(300), phone: z.string().trim().min(3).max(50) }).strict().parse(await json(request));
      const passwordHash = await hashPassword(data.password);
      const userId = await db.transaction(async (tx) => {
        const [exists] = await tx.select({ id: users.id }).from(users).where(eq(users.email, data.email));
        if (exists) throw new ApiError(409, "An account already exists for this email.");
        const [u] = await tx.insert(users).values({ name: data.name, email: data.email, passwordHash, role: data.role, isDemo: DEMO_ENABLED }).returning({ id: users.id });
        await tx.insert(organizations).values({ userId: u.id, name: data.organizationName, address: data.address, phone: data.phone, isDemo: DEMO_ENABLED });
        await tx.insert(auditLogs).values({ actorId: u.id, action: "ACCOUNT_REGISTERED", entity: "user", entityId: u.id, isDemo: DEMO_ENABLED });
        return u.id;
      });
      await createSession(userId);
      return ok({ user: await currentUser() }, 201);
    }
    if (method === "POST" && route === "auth/login") {
      const data = z.object({ email, password: z.string().min(1).max(128) }).strict().parse(await json(request));
      const [u] = await db.select().from(users).where(eq(users.email, data.email));
      const dummyHash = "00000000000000000000000000000000:0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
      const valid = await verifyPassword(data.password, u?.passwordHash ?? dummyHash);
      if (!u || !valid || u.status !== "active" || (!DEMO_ENABLED && u.isDemo)) throw new ApiError(401, "Email or password is incorrect, or this account is inactive.");
      await createSession(u.id);
      return ok({ user: await currentUser() });
    }
    if (method === "POST" && route === "auth/logout") { await endSession(); return ok({ message: "Signed out. Your session has been invalidated." }); }
    if (method === "POST" && route === "auth/forgot-password") {
      const data = z.object({ email }).strict().parse(await json(request));
      if (!emailConfigured()) throw new ApiError(503, "Password reset email is not configured. No email has been sent. Contact your workspace administrator.", "EMAIL_UNAVAILABLE");
      const [u] = await db.select().from(users).where(and(eq(users.email, data.email), eq(users.status, "active")));
      if (u) {
        const token = randomBytes(32).toString("hex");
        const [record] = await db.insert(passwordResetTokens).values({ userId: u.id, tokenHash: digest(token), expiresAt: new Date(Date.now() + 30 * 60000) }).returning();
        try { await sendResetEmail(u.email, token); } catch (e) { await db.delete(passwordResetTokens).where(eq(passwordResetTokens.id, record.id)); throw e; }
      }
      return ok({ message: "If an active account exists, a reset request has been accepted by the email provider." });
    }
    if (method === "POST" && route === "auth/reset-password") {
      const data = z.object({ token: z.string().length(64), password }).strict().parse(await json(request));
      const passwordHash = await hashPassword(data.password);
      await db.transaction(async (tx) => {
        const [token] = await tx.select().from(passwordResetTokens).where(and(eq(passwordResetTokens.tokenHash, digest(data.token)), gt(passwordResetTokens.expiresAt, new Date()), isNull(passwordResetTokens.usedAt))).for("update");
        if (!token) throw new ApiError(400, "This reset link is invalid, expired or already used.");
        await tx.update(users).set({ passwordHash }).where(eq(users.id, token.userId));
        await tx.update(passwordResetTokens).set({ usedAt: new Date() }).where(eq(passwordResetTokens.id, token.id));
        await tx.delete(sessions).where(eq(sessions.userId, token.userId));
        await tx.insert(auditLogs).values({ actorId: token.userId, action: "PASSWORD_RESET", entity: "user", entityId: token.userId });
      });
      await endSession();
      return ok({ message: "Password updated. Sign in with your new password." });
    }
    if (method === "GET" && route === "donations") return ok(await listDonations(query, await currentUser()));
    if (method === "POST" && route === "donations") { const u = await requireUser(["donor"], true); rateLimit(`create:${u.id}`, 15); const id = await createDonation(await json(request), u); return ok(await getDonation(id, u), 201); }
    if (path[0] === "donations" && path[1]) {
      const id = uuid.parse(path[1]);
      if (path.length === 2 && method === "GET") return ok(await getDonation(id, await currentUser()));
      if (path.length === 2 && method === "PATCH") { const u = await requireUser(["donor", "admin"], false); await updateDonation(id, await json(request), u); return ok(await getDonation(id, u)); }
      if (path[2] === "reservations" && method === "POST") { const u = await requireUser(["ngo"], true); rateLimit(`reserve:${u.id}`, 20); const rid = await reserveDonation(id, await json(request), u); return ok({ id: rid, donation: await getDonation(id, u) }, 201); }
    }
    if (path[0] === "matches" && path[1] && method === "GET") return ok({ data: await getMatches(uuid.parse(path[1]), await requireUser(["donor", "ngo", "admin"], true)), method: "Deterministic matching: 50% distance, 30% capacity, 20% collection compatibility. Not a trained AI model." });
    if (method === "GET" && route === "reservations") return ok({ data: await getReservations(await requireUser()) });
    if (path[0] === "reservations" && path[2] === "cancel" && method === "POST") { const u = await requireUser(["ngo", "donor", "admin"]); await cancelReservation(uuid.parse(path[1]), u); return ok({ message: "Reservation cancelled. Uncollected quantity was released." }); }
    if ((path[0] === "pickups" || path[0] === "deliveries") && path[2] === "confirm" && method === "POST") {
      const u = await requireUser(); rateLimit(`confirm:${u.id}`, 30);
      const key = z.string().min(8).max(120).parse(request.headers.get("idempotency-key"));
      const id = path[0] === "pickups" ? await confirmPickup(uuid.parse(path[1]), await json(request), u, key) : await confirmDelivery(uuid.parse(path[1]), await json(request), u, key);
      return ok({ id, message: path[0] === "pickups" ? "Collection recorded." : "Delivery recorded. Confirmed impact has been updated." });
    }
    if (method === "GET" && route === "dashboard/impact") return ok(await getImpact(await currentUser()));
    if (method === "PATCH" && route === "organizations/me") {
      const u = await requireUser();
      const data = z.object({ name: z.string().trim().min(2).max(150), address: z.string().trim().min(3).max(300), phone: z.string().trim().min(3).max(50), latitude: z.coerce.number().min(-90).max(90), longitude: z.coerce.number().min(-180).max(180), capacity: z.coerce.number().int().min(1).max(10000), maxDistanceKm: z.coerce.number().min(1).max(200), dietaryPreferences: z.array(z.enum(["Vegetarian", "Vegan", "Contains meat"])).min(1), collectionStartHour: z.coerce.number().int().min(0).max(23), collectionEndHour: z.coerce.number().int().min(1).max(24) }).strict().refine((v) => v.collectionEndHour > v.collectionStartHour, "End hour must be after start hour.").parse(await json(request));
      const identityChanged = data.name !== u.organization?.name || data.address !== u.organization?.address || data.latitude !== u.organization?.latitude || data.longitude !== u.organization?.longitude;
      await db.transaction(async (tx) => { await tx.update(organizations).set({ ...data, ...(identityChanged && ["donor", "ngo"].includes(u.role) ? { verification: "pending" as const } : {}) }).where(eq(organizations.userId, u.id)); await audit(tx, u, "ORGANIZATION_UPDATED", "organization", u.organization!.id, { verificationRequired: identityChanged }); });
      return ok({ user: await currentUser(), message: identityChanged ? "Profile saved. Organization identity changes require re-verification." : "Profile saved." });
    }
    if (method === "POST" && route === "organizations/me/verification") {
      const u = await requireUser(["donor", "ngo"]);
      const { details } = z.object({ details: z.string().trim().min(20).max(4000) }).strict().parse(await json(request));
      await db.transaction(async (tx) => { await tx.update(organizations).set({ verification: "pending", verificationDetails: details }).where(eq(organizations.userId, u.id)); await audit(tx, u, "VERIFICATION_REQUESTED", "organization", u.organization!.id); });
      return ok({ message: "Verification details submitted for administrator review.", user: await currentUser() });
    }
    if (method === "GET" && route === "notifications") { const u = await requireUser(); return ok({ data: await db.select().from(notifications).where(eq(notifications.userId, u.id)).orderBy(desc(notifications.createdAt)).limit(50) }); }
    if (method === "PATCH" && route === "notifications") { const u = await requireUser(); await db.update(notifications).set({ read: true }).where(eq(notifications.userId, u.id)); return ok({ message: "Notifications marked as read." }); }
    if (method === "POST" && route === "ai/listing-assistant") {
      const u = await requireUser(["donor", "ngo"], true); rateLimit(`ai:${u.id}`, 6);
      const input = await json(request);
      let fields: Record<string, unknown>;
      if (input && typeof input === "object" && "donationId" in input) { const { donationId } = z.object({ donationId: uuid }).strict().parse(input); const d = await getDonation(donationId, u); fields = { title: d.title, description: d.description, category: d.category, dietary: d.dietary, quantity: d.availableQuantity, storage: d.storage, preparedAt: d.preparedAt, pickupFrom: d.pickupFrom, deadline: d.deadline, currentTime: new Date().toISOString() }; }
      else { if (u.role !== "donor") throw new ApiError(403, "Only donors can generate new listing content."); const d = donationInput.parse(input); const { contact: _contact, instructions: _instructions, imageUrl: _image, ...safe } = d; fields = { ...safe, currentTime: new Date().toISOString() }; }
      return ok(await listingAssistant(fields));
    }
    if (method === "POST" && route === "uploads") {
      const u = await requireUser(["donor"], true); rateLimit(`upload:${u.id}`, 10);
      if (Number(request.headers.get("content-length") ?? 0) > 2200000) throw new ApiError(413, "Images must be smaller than 2 MB.");
      const form = await request.formData(), file = form.get("image");
      if (!(file instanceof File) || file.size > 2 * 1024 * 1024 || file.size < 16) throw new ApiError(400, "Choose a valid JPEG or PNG image smaller than 2 MB.");
      const bytes = Buffer.from(await file.arrayBuffer());
      const isPng = bytes.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
      const isJpeg = bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255 && bytes[bytes.length - 2] === 255 && bytes[bytes.length - 1] === 217;
      if (!(isPng && file.type === "image/png") && !(isJpeg && file.type === "image/jpeg")) throw new ApiError(400, "Image content must be a valid JPEG or PNG. Other file types are not accepted.");
      let sanitized: Buffer;
      try { sanitized = await sharp(bytes, { limitInputPixels: 20000000, animated: false }).rotate().resize({ width: 1600, height: 1600, fit: "inside", withoutEnlargement: true }).jpeg({ quality: 88 }).toBuffer(); }
      catch { throw new ApiError(400, "This file could not be decoded as an image, or exceeds 20 megapixels."); }
      const [record] = await db.insert(media).values({ userId: u.id, mimeType: "image/jpeg", data: sanitized.toString("base64") }).returning({ id: media.id });
      return ok({ url: `/api/v1/media/${record.id}` }, 201);
    }
    if (path[0] === "media" && path[1] && method === "GET") {
      const [image] = await db.select().from(media).where(eq(media.id, uuid.parse(path[1])));
      if (!image) throw new ApiError(404, "Image not found.");
      return new Response(Buffer.from(image.data, "base64"), { headers: { "Content-Type": image.mimeType, "X-Content-Type-Options": "nosniff", "Content-Security-Policy": "default-src 'none'; sandbox", "Cache-Control": "public, max-age=86400" } });
    }
    if (route.startsWith("admin/")) {
      const u = await requireUser(["admin"]);
      if (method === "GET" && route === "admin/reports") return ok({ data: await db.select({ report: reports, title: donations.title, reporter: users.name, email: users.email }).from(reports).innerJoin(donations, eq(reports.donationId, donations.id)).innerJoin(users, eq(reports.reporterId, users.id)).where(eq(reports.isDemo, u.isDemo)).orderBy(desc(reports.createdAt)).limit(100) });
      if (path[1] === "reports" && path[2] && method === "PATCH") {
        const id = uuid.parse(path[2]); const { resolution } = z.object({ resolution: z.string().trim().min(10).max(2000) }).strict().parse(await json(request));
        await db.transaction(async (tx) => {
          const [report] = await tx.select().from(reports).where(and(eq(reports.id, id), eq(reports.isDemo, u.isDemo))).for("update");
          if (!report) throw new ApiError(404, "Report not found.");
          await tx.update(reports).set({ status: "reviewed", resolution, resolvedBy: u.id, resolvedAt: new Date() }).where(eq(reports.id, id));
          await audit(tx, u, "CONCERN_REVIEWED", "report", id);
          await tx.insert(notifications).values({ userId: report.reporterId, title: "Your concern has been reviewed", message: resolution });
        });
        return ok({ message: "Review recorded and reporter notified in the app." });
      }
      if (method === "GET" && route === "admin/organizations/pending") return ok({ data: await db.select({ organization: organizations, user: { id: users.id, email: users.email, name: users.name, role: users.role } }).from(organizations).innerJoin(users, eq(organizations.userId, users.id)).where(and(eq(organizations.verification, "pending"), eq(organizations.isDemo, u.isDemo))) });
      if (method === "GET" && route === "admin/accounts") return ok({ data: await db.select({ id: users.id, name: users.name, email: users.email, role: users.role, status: users.status, isDemo: users.isDemo }).from(users).where(eq(users.isDemo, u.isDemo)) });
      if (method === "GET" && route === "admin/audit") return ok({ data: await db.select().from(auditLogs).where(eq(auditLogs.isDemo, u.isDemo)).orderBy(desc(auditLogs.createdAt)).limit(100) });
      if (path[1] === "organizations" && path[3] === "verification" && method === "PATCH") {
        const id = uuid.parse(path[2]); const data = z.object({ verification: z.enum(["verified", "rejected"]) }).strict().parse(await json(request));
        await db.transaction(async (tx) => { const [org] = await tx.select().from(organizations).where(and(eq(organizations.id, id), eq(organizations.isDemo, u.isDemo))).for("update"); if (!org) throw new ApiError(404, "Organization not found."); await tx.update(organizations).set(data).where(eq(organizations.id, id)); await audit(tx, u, "VERIFICATION_REVIEWED", "organization", id, data); await tx.insert(notifications).values({ userId: org.userId, title: "Verification reviewed", message: `Your organization verification is ${data.verification}.` }); });
        return ok({ message: "Verification decision saved." });
      }
      if (path[1] === "accounts" && path[2] && method === "PATCH") {
        const id = uuid.parse(path[2]); const data = z.object({ status: z.enum(["active", "suspended"]).optional(), role: z.enum(["donor", "ngo", "volunteer", "admin"]).optional() }).strict().refine((v) => v.status || v.role, "Provide a role or status.").parse(await json(request));
        if (id === u.id) throw new ApiError(409, "You cannot change your own administrator account here.");
        await db.transaction(async (tx) => { const [account] = await tx.select().from(users).where(and(eq(users.id, id), eq(users.isDemo, u.isDemo))).for("update"); if (!account) throw new ApiError(404, "Account not found."); await tx.update(users).set(data).where(eq(users.id, id)); await tx.delete(sessions).where(eq(sessions.userId, id)); await audit(tx, u, "ACCOUNT_UPDATED", "user", id, data); });
        return ok({ message: "Account updated. Existing sessions were invalidated." });
      }
    }
    throw new ApiError(404, "API endpoint not found.", "NOT_FOUND");
  } catch (error) {
    if (error instanceof z.ZodError) return ok({ error: { code: "VALIDATION_ERROR", message: error.issues.map((i) => `${i.path.join(".") || "Input"}: ${i.message}`).join(" "), fields: error.flatten().fieldErrors } }, 422);
    if (error instanceof ApiError) return ok({ error: { code: error.code, message: error.message } }, error.status);
    const code = (error as { code?: string })?.code;
    if (code === "23505") return ok({ error: { code: "CONFLICT", message: "This record already exists. Refresh and try again." } }, 409);
    console.error("Refill API failed", { type: error instanceof Error ? error.name : "Unknown", databaseCode: code });
    return ok({ error: { code: "SERVICE_UNAVAILABLE", message: "The service could not complete this request. Please retry; no successful action is being claimed." } }, 503);
  }
}
