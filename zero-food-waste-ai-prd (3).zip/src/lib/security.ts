import { createHash, randomBytes, scrypt, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { organizations, sessions, users } from "@/db/schema";
import type { Role, User } from "./types";

export const DEMO_ENABLED = process.env.APP_ENV !== "production";
export class ApiError extends Error {
  constructor(public status: number, message: string, public code = "REQUEST_FAILED") { super(message); }
}
export const digest = (value: string) => createHash("sha256").update(value).digest("hex");
const derive = (password: string, salt: string) => new Promise<Buffer>((resolve, reject) => {
  scrypt(password, salt, 64, { N: 16384, r: 8, p: 1 }, (error, key) => error ? reject(error) : resolve(key));
});
export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  return `${salt}:${(await derive(password, salt)).toString("hex")}`;
}
export async function verifyPassword(password: string, encoded: string) {
  const [salt, hash] = encoded.split(":");
  if (!salt || !hash) return false;
  const actual = await derive(password, salt);
  const expected = Buffer.from(hash, "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
export async function currentUser(): Promise<User | null> {
  const token = (await cookies()).get("refill_session")?.value;
  if (!token) return null;
  const [row] = await db.select({ user: users }).from(sessions).innerJoin(users, eq(sessions.userId, users.id)).where(and(eq(sessions.tokenHash, digest(token)), gt(sessions.expiresAt, new Date()))).limit(1);
  if (!row || row.user.status !== "active" || (!DEMO_ENABLED && row.user.isDemo)) return null;
  const [org] = await db.select().from(organizations).where(eq(organizations.userId, row.user.id)).limit(1);
  const u = row.user;
  return { id: u.id, name: u.name, email: u.email, role: u.role, isDemo: u.isDemo, organization: org ? { id: org.id, name: org.name, address: org.address, phone: org.phone, latitude: org.latitude, longitude: org.longitude, verification: org.verification, capacity: org.capacity, maxDistanceKm: org.maxDistanceKm, dietaryPreferences: org.dietaryPreferences, collectionStartHour: org.collectionStartHour, collectionEndHour: org.collectionEndHour, isDemo: org.isDemo } : null };
}
export async function requireUser(roles?: Role[], verified = false) {
  const user = await currentUser();
  if (!user) throw new ApiError(401, "Please sign in to continue.", "UNAUTHENTICATED");
  authorize(user, roles, verified);
  return user;
}
export function authorize(user: User, roles?: Role[], verified = false) {
  if (roles && !roles.includes(user.role)) throw new ApiError(403, "Your role is not permitted to perform this action.", "FORBIDDEN");
  if (verified && user.organization?.verification !== "verified") throw new ApiError(403, "Your organization must be verified before participating in donations.", "VERIFICATION_REQUIRED");
}
export async function createSession(userId: string) {
  await endSession();
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + 7 * 24 * 3600000);
  await db.insert(sessions).values({ userId, tokenHash: digest(token), expiresAt });
  (await cookies()).set("refill_session", token, { httpOnly: true, sameSite: "lax", secure: process.env.APP_ENV === "production", path: "/", expires: expiresAt });
}
export async function endSession() {
  const jar = await cookies();
  const token = jar.get("refill_session")?.value;
  if (token) await db.delete(sessions).where(eq(sessions.tokenHash, digest(token)));
  jar.delete("refill_session");
}
export function assertOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (!origin) throw new ApiError(403, "An Origin header is required for this request.", "CSRF_REJECTED");
  let host: string;
  try { host = new URL(origin).host; } catch { throw new ApiError(403, "Invalid request origin."); }
  const allowed = [new URL(request.url).host, request.headers.get("host"), request.headers.get("x-forwarded-host")];
  if (process.env.FRONTEND_URL) allowed.push(new URL(process.env.FRONTEND_URL).host);
  if (!allowed.includes(host)) throw new ApiError(403, "This request came from an untrusted origin.", "CSRF_REJECTED");
}
const buckets = new Map<string, { count: number; until: number }>();
export function rateLimit(key: string, limit = 30, windowMs = 60000) {
  const now = Date.now();
  let bucket = buckets.get(key);
  if (!bucket || bucket.until <= now) { bucket = { count: 0, until: now + windowMs }; buckets.set(key, bucket); }
  bucket.count++;
  if (bucket.count > limit) throw new ApiError(429, "Too many requests. Please wait a minute and try again.", "RATE_LIMITED");
  if (buckets.size > 10000) for (const [k, b] of buckets) if (b.until < now) buckets.delete(k);
}
