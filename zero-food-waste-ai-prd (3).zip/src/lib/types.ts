export type Role = "donor" | "ngo" | "volunteer" | "admin";
export type DonationStatus = "AVAILABLE" | "PARTIALLY_RESERVED" | "RESERVED" | "PICKED_UP" | "DELIVERED" | "EXPIRED" | "CANCELLED";
export interface Organization {
  id: string; name: string; address: string; phone: string; latitude: number; longitude: number;
  verification: "pending" | "verified" | "rejected"; capacity: number; maxDistanceKm: number;
  dietaryPreferences: string[]; collectionStartHour: number; collectionEndHour: number; isDemo: boolean;
}
export interface User { id: string; email: string; name: string; role: Role; isDemo: boolean; organization: Organization | null; }
export interface Donation {
  id: string; title: string; description: string; category: string; dietary: string;
  quantity: number; availableQuantity: number; allocatedQuantity: number; preparedAt: string;
  plannedPreparation: boolean; storage: string; location: string; latitude: number; longitude: number;
  pickupFrom: string; deadline: string; instructions?: string; contact?: string; imageUrl: string | null;
  status: DonationStatus; donorId: string; donorName: string; verified: boolean; isDemo: boolean;
  distance: number; createdAt: string;
}
export interface Reservation {
  id: string; donationId: string; ngoId: string; ngoName: string; donorName: string;
  volunteerId: string | null; volunteerName: string | null; quantity: number; allocatedQuantity: number;
  pickedQuantity: number; deliveredQuantity: number; pickupClosed: boolean; deliveryClosed: boolean;
  status: string; expiresAt: string; createdAt: string; donation: Donation;
}
export interface Match { id: string; name: string; distance: number; capacity: number; score: number; reasons: string[]; }
export interface Impact {
  listed: number; reserved: number; pickedUp: number; delivered: number; completed: number;
  expired: number; cancelled: number; activeDonors: number; verifiedNgos: number; available: number;
  activeListings: number; weekly: { day: string; date: string; listed: number; delivered: number }[];
  history: { id: string; title: string; organization: string; quantity: number; confirmedAt: string }[];
}
export interface Notification { id: string; title: string; message: string; read: boolean; createdAt: string; }
export interface Bootstrap { user: User | null; demo: boolean; aiConfigured: boolean; emailConfigured: boolean; }
export interface AssistantResult { description: string; summary: string; urgency: string; nextSteps: string[]; warnings: string[]; }
export type Page = "overview" | "marketplace" | "donations" | "pickups" | "impact" | "settings" | "admin" | "create" | "detail" | "login" | "register" | "reset";
