import { and, eq, gt, lt, inArray, sql, desc, ilike, or, type SQL } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { auditLogs, deliveries, donations, notifications, organizations, pickups, reservations, users } from "@/db/schema";
import { ApiError, authorize, DEMO_ENABLED } from "./security";
import type { Donation, Impact, Match, Reservation, User } from "./types";

export type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];
type DonationRow = typeof donations.$inferSelect;
type OrgRow = typeof organizations.$inferSelect;
export const donationInput = z.object({
  title: z.string().trim().min(3).max(150), description: z.string().trim().min(10).max(4000),
  category: z.enum(["Cooked meals", "Bakery", "Fresh produce", "Packaged food"]),
  dietary: z.enum(["Vegetarian", "Vegan", "Contains meat"]), quantity: z.coerce.number().int().min(1).max(10000),
  preparedAt: z.coerce.date(), plannedPreparation: z.boolean().default(false), storage: z.string().trim().min(5).max(2000),
  location: z.string().trim().min(3).max(300), latitude: z.coerce.number().min(-90).max(90), longitude: z.coerce.number().min(-180).max(180),
  pickupFrom: z.coerce.date(), deadline: z.coerce.date(), instructions: z.string().trim().min(5).max(2000),
  contact: z.string().trim().min(3).max(200), imageUrl: z.string().max(150).regex(/^\/(images\/[a-z-]+\.jpg|api\/v1\/media\/[0-9a-f-]{36})$/).nullable().optional(),
}).strict().superRefine((value, context) => {
  const issue = (path: string, message: string) => context.addIssue({ code: "custom", path: [path], message });
  if (value.deadline.getTime() <= Date.now()) issue("deadline", "Collection deadline must be in the future.");
  if (value.deadline <= value.pickupFrom) issue("deadline", "Deadline must be after the earliest pickup time.");
  if (value.preparedAt.getTime() > Date.now() + 60000 && !value.plannedPreparation) issue("preparedAt", "Future preparation must be marked as planned.");
  if (value.pickupFrom < value.preparedAt) issue("pickupFrom", "Pickup cannot begin before preparation.");
  if (value.deadline.getTime() > Date.now() + 7 * 86400000) issue("deadline", "The collection window cannot exceed seven days.");
});
export const quantityInput = z.object({ quantity: z.coerce.number().int().min(1).max(10000) }).strict();
export const confirmationInput = z.object({ quantity: z.coerce.number().int().min(1).max(10000), final: z.boolean().default(true) }).strict();
export const scope = (user: User | null) => user?.isDemo ?? DEMO_ENABLED;

export const distanceKm = (lat1: number, lon1: number, lat2: number, lon2: number) => {
  const rad = (n: number) => n * Math.PI / 180;
  const a = Math.sin(rad(lat2 - lat1) / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(rad(lon2 - lon1) / 2) ** 2;
  return Math.round(6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(Math.max(0, 1 - a))) * 10) / 10;
};
export async function audit(tx: Tx, actor: User | null, action: string, entity: string, entityId: string, metadata: Record<string, unknown> = {}, isDemo = actor?.isDemo ?? false) {
  await tx.insert(auditLogs).values({ actorId: actor?.id ?? null, action, entity, entityId, metadata, isDemo });
}
async function notify(tx: Tx, userId: string, title: string, message: string) {
  await tx.insert(notifications).values({ userId, title, message });
}
async function lockedDonation(tx: Tx, id: string) {
  const [d] = await tx.select().from(donations).where(eq(donations.id, id)).for("update");
  if (!d) throw new ApiError(404, "Donation not found.", "NOT_FOUND");
  return d;
}
export async function refreshStatus(tx: Tx, id: string) {
  const [d] = await tx.select().from(donations).where(eq(donations.id, id));
  if (!d || d.status === "CANCELLED") return;
  const rows = await tx.select().from(reservations).where(and(eq(reservations.donationId, id), inArray(reservations.status, ["RESERVED", "PARTIALLY_PICKED_UP", "PICKED_UP", "PARTIALLY_DELIVERED", "DELIVERED"])));
  let status: DonationRow["status"] = "AVAILABLE";
  if (d.allocatedQuantity === d.quantity && rows.length && rows.every((r) => r.deliveryClosed)) status = "DELIVERED";
  else if (d.allocatedQuantity === d.quantity && rows.length && rows.every((r) => r.pickupClosed)) status = "PICKED_UP";
  else if (d.deadline <= new Date() && d.allocatedQuantity < d.quantity) status = "EXPIRED";
  else if (d.allocatedQuantity === d.quantity) status = "RESERVED";
  else if (d.allocatedQuantity > 0) status = "PARTIALLY_RESERVED";
  await tx.update(donations).set({ status }).where(eq(donations.id, id));
}
async function releaseExpired(tx: Tx, d: DonationRow) {
  const rows = await tx.select().from(reservations).where(and(eq(reservations.donationId, d.id), lt(reservations.expiresAt, new Date()), eq(reservations.pickupClosed, false), inArray(reservations.status, ["RESERVED", "PARTIALLY_PICKED_UP"]))).for("update");
  for (const r of rows) {
    const released = r.allocatedQuantity - r.pickedQuantity;
    await tx.update(donations).set({ allocatedQuantity: sql`${donations.allocatedQuantity} - ${released}` }).where(eq(donations.id, d.id));
    await tx.update(reservations).set({ allocatedQuantity: r.pickedQuantity, pickupClosed: true, status: r.pickedQuantity > 0 ? "PICKED_UP" : "EXPIRED" }).where(eq(reservations.id, r.id));
    await audit(tx, null, "RESERVATION_EXPIRED", "reservation", r.id, { released }, d.isDemo);
  }
  if (rows.length || (d.deadline < new Date() && ["AVAILABLE", "PARTIALLY_RESERVED"].includes(d.status))) await refreshStatus(tx, d.id);
}
export async function sweepExpired() {
  const expired = await db.select({ id: donations.id }).from(donations).where(and(lt(donations.deadline, new Date()), inArray(donations.status, ["AVAILABLE", "PARTIALLY_RESERVED", "RESERVED"])));
  const expiredReservations = await db.select({ id: reservations.donationId }).from(reservations).where(and(lt(reservations.expiresAt, new Date()), eq(reservations.pickupClosed, false), inArray(reservations.status, ["RESERVED", "PARTIALLY_PICKED_UP"])));
  for (const id of new Set([...expired, ...expiredReservations].map((x) => x.id))) await db.transaction(async (tx) => { const d = await lockedDonation(tx, id); await releaseExpired(tx, d); });
}
export function donationView(d: DonationRow, org: OrgRow, user: User | null, includePrivate = false): Donation {
  return { id: d.id, donorId: d.donorId, donorName: org.name, verified: org.verification === "verified", title: d.title, description: d.description, category: d.category, dietary: d.dietary, quantity: d.quantity, availableQuantity: Math.max(0, d.quantity - d.allocatedQuantity), allocatedQuantity: d.allocatedQuantity, preparedAt: d.preparedAt.toISOString(), plannedPreparation: d.plannedPreparation, storage: d.storage, location: d.location, latitude: d.latitude, longitude: d.longitude, pickupFrom: d.pickupFrom.toISOString(), deadline: d.deadline.toISOString(), imageUrl: d.imageUrl, status: d.status, isDemo: d.isDemo, distance: distanceKm(user?.organization?.latitude ?? 12.9716, user?.organization?.longitude ?? 77.5946, d.latitude, d.longitude), createdAt: d.createdAt.toISOString(), ...(includePrivate ? { instructions: d.instructions, contact: d.contact || "Contact the organization through your reservation." } : {}) };
}
export async function getDonation(id: string, user: User | null) {
  await sweepExpired();
  const [row] = await db.select({ d: donations, org: organizations, ownerStatus: users.status }).from(donations).innerJoin(organizations, eq(donations.donorId, organizations.id)).innerJoin(users, eq(organizations.userId, users.id)).where(and(eq(donations.id, id), eq(donations.isDemo, scope(user))));
  if (!row) throw new ApiError(404, "Donation not found.");
  let privateAccess = user?.role === "admin" || user?.organization?.id === row.d.donorId;
  if (user && !privateAccess) {
    const [r] = await db.select().from(reservations).where(and(eq(reservations.donationId, id), or(eq(reservations.ngoId, user.organization?.id ?? "00000000-0000-0000-0000-000000000000"), eq(reservations.volunteerId, user.id)), inArray(reservations.status, ["RESERVED", "PARTIALLY_PICKED_UP", "PICKED_UP", "PARTIALLY_DELIVERED", "DELIVERED"]))).limit(1);
    privateAccess = !!r;
  }
  if (!privateAccess && (row.org.verification !== "verified" || row.ownerStatus !== "active")) throw new ApiError(404, "This donation is not publicly available.");
  return donationView(row.d, row.org, user, !!privateAccess);
}
export async function listDonations(params: URLSearchParams, user: User | null) {
  await sweepExpired();
  const filters: SQL[] = [eq(donations.isDemo, scope(user))];
  if (params.get("own") === "true") {
    if (!user) throw new ApiError(401, "Please sign in.");
    authorize(user, ["donor"], false);
    filters.push(eq(donations.donorId, user.organization!.id));
  } else filters.push(eq(organizations.verification, "verified"), eq(users.status, "active"), gt(donations.deadline, new Date()), inArray(donations.status, ["AVAILABLE", "PARTIALLY_RESERVED"]), sql`${donations.allocatedQuantity} < ${donations.quantity}`);
  const search = params.get("search")?.trim().slice(0, 100);
  if (search) filters.push(or(ilike(donations.title, `%${search}%`), ilike(donations.location, `%${search}%`), ilike(organizations.name, `%${search}%`))!);
  if (["Vegetarian", "Vegan", "Contains meat"].includes(params.get("diet") ?? "")) filters.push(eq(donations.dietary, params.get("diet")!));
  if (["Cooked meals", "Bakery", "Fresh produce", "Packaged food"].includes(params.get("category") ?? "")) filters.push(eq(donations.category, params.get("category")!));
  const min = Number(params.get("minQuantity") ?? 1);
  if (Number.isFinite(min) && min > 0) filters.push(sql`${donations.quantity} - ${donations.allocatedQuantity} >= ${min}`);
  const maxHours = Number(params.get("maxHours") ?? 0);
  if (Number.isFinite(maxHours) && maxHours > 0) filters.push(lt(donations.deadline, new Date(Date.now() + maxHours * 3600000)));
  const lat = user?.organization?.latitude ?? 12.9716, lng = user?.organization?.longitude ?? 77.5946;
  const distance = sql<number>`6371 * acos(least(1.0, greatest(-1.0, sin(radians(${lat}::double precision)) * sin(radians(${donations.latitude})) + cos(radians(${lat}::double precision)) * cos(radians(${donations.latitude})) * cos(radians(${donations.longitude} - ${lng}::double precision)))))`;
  const maxDistance = Number(params.get("distance") ?? 0);
  if (Number.isFinite(maxDistance) && maxDistance > 0) filters.push(sql`${distance} <= ${maxDistance}`);
  const sort = params.get("sort");
  const order = sort === "urgency" ? donations.deadline : sort === "distance" ? distance : desc(donations.createdAt);
  const page = Math.min(100000, Math.max(1, Math.floor(Number(params.get("page")) || 1))), limit = Math.min(24, Math.max(1, Math.floor(Number(params.get("limit")) || 12)));
  const [count] = await db.select({ total: sql<number>`count(*)::int` }).from(donations).innerJoin(organizations, eq(donations.donorId, organizations.id)).innerJoin(users, eq(organizations.userId, users.id)).where(and(...filters));
  const rows = await db.select({ d: donations, org: organizations }).from(donations).innerJoin(organizations, eq(donations.donorId, organizations.id)).innerJoin(users, eq(organizations.userId, users.id)).where(and(...filters)).orderBy(order, donations.id).limit(limit).offset((page - 1) * limit);
  return { data: rows.map((row) => donationView(row.d, row.org, user, user?.organization?.id === row.d.donorId)), total: count.total, page, limit };
}
function compatibleHours(org: OrgRow, d: DonationRow) {
  const earliest = Math.max(Date.now(), d.pickupFrom.getTime());
  for (let t = earliest; t < d.deadline.getTime(); t += 15 * 60000) {
    const hour = ((new Date(t).getUTCHours() + new Date(t).getUTCMinutes() / 60 + 5.5) % 24);
    if (hour >= org.collectionStartHour && hour < org.collectionEndHour) return true;
  }
  return false;
}
export async function matchesFor(client: Tx | typeof db, d: DonationRow, requiredQuantity = 1): Promise<Match[]> {
  if (d.deadline <= new Date() || ["CANCELLED", "EXPIRED", "DELIVERED"].includes(d.status) || d.allocatedQuantity >= d.quantity) return [];
  const candidates = await client.select({ org: organizations }).from(organizations).innerJoin(users, eq(organizations.userId, users.id)).where(and(eq(users.role, "ngo"), eq(users.status, "active"), eq(organizations.verification, "verified"), eq(organizations.isDemo, d.isDemo)));
  const result: Match[] = [];
  for (const { org } of candidates) {
    const busy = await client.select({ allocated: reservations.allocatedQuantity }).from(reservations).where(and(eq(reservations.ngoId, org.id), inArray(reservations.status, ["RESERVED", "PARTIALLY_PICKED_UP", "PICKED_UP", "PARTIALLY_DELIVERED"])));
    const capacity = Math.max(0, org.capacity - busy.reduce((n, r) => n + r.allocated, 0));
    const distance = distanceKm(d.latitude, d.longitude, org.latitude, org.longitude);
    if (capacity < requiredQuantity || distance > org.maxDistanceKm || !org.dietaryPreferences.includes(d.dietary) || !compatibleHours(org, d)) continue;
    const score = Math.round(50 * Math.max(0, 1 - distance / org.maxDistanceKm) + 30 * Math.min(1, capacity / Math.max(1, d.quantity - d.allocatedQuantity)) + 20);
    result.push({ id: org.id, name: org.name, distance, capacity, score, reasons: ["Verified organization", `${distance} km from pickup · within ${org.maxDistanceKm} km collection radius`, `Capacity for ${capacity} meal portions`, "Collection hours overlap with the pickup window", `${d.dietary} meals meet recipient requirements`] });
  }
  return result.sort((a, b) => b.score - a.score);
}
export async function getMatches(id: string, user: User) {
  authorize(user, ["donor", "ngo", "admin"], user.role !== "admin");
  await getDonation(id, user);
  const [d] = await db.select().from(donations).where(and(eq(donations.id, id), eq(donations.isDemo, user.isDemo)));
  if (!d) throw new ApiError(404, "Donation not found.");
  if (user.role === "donor" && user.organization?.id !== d.donorId) throw new ApiError(403, "You can only view matches for your own donations.");
  return matchesFor(db, d);
}
export async function createDonation(input: unknown, user: User) {
  authorize(user, ["donor"], true);
  const data = donationInput.parse(input);
  if (data.imageUrl?.startsWith("/api/v1/media/")) {
    const { media } = await import("@/db/schema");
    const [image] = await db.select().from(media).where(and(eq(media.id, data.imageUrl.split("/").pop()!), eq(media.userId, user.id)));
    if (!image) throw new ApiError(400, "This image does not belong to your account.");
  }
  return db.transaction(async (tx) => {
    const [d] = await tx.insert(donations).values({ ...data, donorId: user.organization!.id, isDemo: user.isDemo }).returning();
    await audit(tx, user, "DONATION_CREATED", "donation", d.id, { quantity: d.quantity });
    return d.id;
  });
}
export async function updateDonation(id: string, input: unknown, user: User) {
  authorize(user, ["donor", "admin"]);
  return db.transaction(async (tx) => {
    let d = await lockedDonation(tx, id);
    if (d.isDemo !== user.isDemo || (user.role !== "admin" && d.donorId !== user.organization?.id)) throw new ApiError(403, "You cannot change another organization's donation.");
    await releaseExpired(tx, d);
    d = await lockedDonation(tx, id);
    const cancel = z.object({ status: z.literal("CANCELLED") }).strict().safeParse(input);
    if (cancel.success) {
      if (d.status === "CANCELLED") return id;
      if (["DELIVERED", "PICKED_UP"].includes(d.status)) throw new ApiError(409, "Collected or delivered donations cannot be cancelled.");
      const active = await tx.select().from(reservations).where(and(eq(reservations.donationId, id), inArray(reservations.status, ["RESERVED", "PARTIALLY_PICKED_UP", "PICKED_UP", "PARTIALLY_DELIVERED"])));
      if (active.length) throw new ApiError(409, "Cancel active reservations before cancelling this listing.");
      await tx.update(donations).set({ status: "CANCELLED" }).where(eq(donations.id, id));
      await audit(tx, user, "DONATION_CANCELLED", "donation", id);
    } else {
      authorize(user, ["donor", "admin"], user.role === "donor");
      if (["CANCELLED", "DELIVERED", "EXPIRED"].includes(d.status)) throw new ApiError(409, "This listing can no longer be edited.");
      const data = donationInput.parse(input);
      if (data.imageUrl?.startsWith("/api/v1/media/")) {
        const { media } = await import("@/db/schema");
        const [image] = await tx.select().from(media).where(and(eq(media.id, data.imageUrl.split("/").pop()!), eq(media.userId, user.id)));
        if (!image) throw new ApiError(400, "This image does not belong to your account.");
      }
      if (data.quantity < d.allocatedQuantity) throw new ApiError(409, `At least ${d.allocatedQuantity} portions are already committed. Quantity cannot be lower.`);
      await tx.update(donations).set(data).where(eq(donations.id, id));
      await refreshStatus(tx, id);
      await audit(tx, user, "DONATION_UPDATED", "donation", id, { quantity: data.quantity });
    }
    return id;
  });
}
export async function reserveDonation(id: string, input: unknown, user: User) {
  authorize(user, ["ngo"], true);
  const { quantity } = quantityInput.parse(input);
  return db.transaction(async (tx) => {
    let d = await lockedDonation(tx, id);
    if (d.isDemo !== user.isDemo) throw new ApiError(404, "Donation not found.");
    const [owner] = await tx.select({ org: organizations, status: users.status }).from(organizations).innerJoin(users, eq(organizations.userId, users.id)).where(eq(organizations.id, d.donorId));
    if (!owner || owner.org.verification !== "verified" || owner.status !== "active") throw new ApiError(409, "This donor is not currently verified and active. The listing cannot accept reservations.", "DONOR_UNAVAILABLE");
    await releaseExpired(tx, d);
    d = await lockedDonation(tx, id);
    if (d.deadline <= new Date() || !["AVAILABLE", "PARTIALLY_RESERVED"].includes(d.status)) throw new ApiError(409, "This donation is no longer available for collection.", "NOT_AVAILABLE");
    if (quantity > d.quantity - d.allocatedQuantity) throw new ApiError(409, `Only ${d.quantity - d.allocatedQuantity} portions remain available.`, "INSUFFICIENT_QUANTITY");
    const [ngo] = await tx.select().from(organizations).where(eq(organizations.id, user.organization!.id)).for("update");
    const [account] = await tx.select().from(users).where(eq(users.id, user.id)).for("update");
    if (!ngo || ngo.verification !== "verified" || !account || account.status !== "active" || account.role !== "ngo") throw new ApiError(403, "Your NGO account is not currently verified and active.");
    const eligible = await matchesFor(tx, d, quantity);
    if (!eligible.some((m) => m.id === user.organization!.id)) throw new ApiError(409, "Your organization's capacity, dietary requirements, distance or collection hours do not match this donation.", "NO_ELIGIBLE_MATCH");
    const [volunteer] = await tx.select({ id: users.id }).from(users).where(and(eq(users.role, "volunteer"), eq(users.status, "active"), eq(users.isDemo, user.isDemo))).orderBy(users.createdAt).limit(1);
    const minutes = Math.max(5, Math.min(360, Number(process.env.RESERVATION_TTL_MINUTES) || 60));
    const expiresAt = new Date(Math.min(d.deadline.getTime(), Math.max(Date.now(), d.pickupFrom.getTime()) + minutes * 60000));
    const [r] = await tx.insert(reservations).values({ donationId: id, ngoId: user.organization!.id, volunteerId: volunteer?.id ?? null, quantity, allocatedQuantity: quantity, expiresAt }).returning();
    await tx.update(donations).set({ allocatedQuantity: sql`${donations.allocatedQuantity} + ${quantity}` }).where(eq(donations.id, id));
    await refreshStatus(tx, id);
    await audit(tx, user, "MEALS_RESERVED", "reservation", r.id, { quantity, donationId: id });
    await notify(tx, owner.org.userId, "Your food has a destination", `${user.organization!.name} reserved ${quantity} portions of ${d.title}.`);
    if (volunteer) await notify(tx, volunteer.id, "New pickup assigned", `Collect ${quantity} portions of ${d.title} before ${expiresAt.toISOString()}.`);
    return r.id;
  });
}
async function lockedReservation(tx: Tx, id: string, user: User) {
  const [initial] = await tx.select().from(reservations).where(eq(reservations.id, id));
  if (!initial) throw new ApiError(404, "Reservation not found.");
  const d = await lockedDonation(tx, initial.donationId);
  if (d.isDemo !== user.isDemo) throw new ApiError(404, "Reservation not found.");
  await releaseExpired(tx, d);
  const [r] = await tx.select().from(reservations).where(eq(reservations.id, id)).for("update");
  return { d, r };
}
export async function cancelReservation(id: string, user: User) {
  authorize(user, ["ngo", "donor", "admin"]);
  return db.transaction(async (tx) => {
    const { d, r } = await lockedReservation(tx, id, user);
    if (!(user.role === "admin" || r.ngoId === user.organization?.id || d.donorId === user.organization?.id)) throw new ApiError(403, "You cannot cancel another organization's reservation.");
    if (["CANCELLED", "EXPIRED"].includes(r.status)) return id;
    if (r.pickedQuantity > 0) throw new ApiError(409, "Collected meals cannot be released back into the marketplace.");
    await tx.update(reservations).set({ status: "CANCELLED", allocatedQuantity: 0, pickupClosed: true, deliveryClosed: true }).where(eq(reservations.id, id));
    await tx.update(donations).set({ allocatedQuantity: sql`${donations.allocatedQuantity} - ${r.allocatedQuantity}` }).where(eq(donations.id, d.id));
    await refreshStatus(tx, d.id);
    await audit(tx, user, "RESERVATION_CANCELLED", "reservation", id, { released: r.allocatedQuantity });
    return id;
  });
}
export async function confirmPickup(id: string, input: unknown, user: User, key: string) {
  authorize(user, ["volunteer", "donor"], user.role === "donor");
  const { quantity, final } = confirmationInput.parse(input);
  return db.transaction(async (tx) => {
    const { d, r } = await lockedReservation(tx, id, user);
    if (!(user.role === "volunteer" && r.volunteerId === user.id) && !(user.role === "donor" && d.donorId === user.organization?.id)) throw new ApiError(403, "Only the assigned volunteer or the listing's donor can confirm pickup.");
    const fullKey = `pickup:${id}:${key}`;
    const [existing] = await tx.select().from(pickups).where(eq(pickups.idempotencyKey, fullKey));
    if (existing) { if (existing.quantity !== quantity) throw new ApiError(409, "This idempotency key was used for a different quantity."); return existing.id; }
    if (r.pickupClosed || !["RESERVED", "PARTIALLY_PICKED_UP"].includes(r.status)) throw new ApiError(409, "Pickup is closed, cancelled or expired.", "INVALID_TRANSITION");
    if (new Date() < d.pickupFrom) throw new ApiError(409, "The pickup window has not started yet.");
    if (new Date() >= r.expiresAt || new Date() >= d.deadline) throw new ApiError(409, "The collection window has expired.");
    if (quantity > r.allocatedQuantity - r.pickedQuantity) throw new ApiError(409, `You can collect at most ${r.allocatedQuantity - r.pickedQuantity} more portions.`);
    const pickedQuantity = r.pickedQuantity + quantity, pickupClosed = final || pickedQuantity === r.allocatedQuantity;
    const released = pickupClosed ? r.allocatedQuantity - pickedQuantity : 0;
    const [p] = await tx.insert(pickups).values({ reservationId: id, volunteerId: user.id, quantity, idempotencyKey: fullKey }).returning();
    await tx.update(reservations).set({ pickedQuantity, pickupClosed, allocatedQuantity: r.allocatedQuantity - released, status: pickupClosed ? "PICKED_UP" : "PARTIALLY_PICKED_UP" }).where(eq(reservations.id, id));
    if (released) await tx.update(donations).set({ allocatedQuantity: sql`${donations.allocatedQuantity} - ${released}` }).where(eq(donations.id, d.id));
    await refreshStatus(tx, d.id);
    await audit(tx, user, "PICKUP_CONFIRMED", "reservation", id, { quantity, released, final: pickupClosed });
    const [ngo] = await tx.select({ userId: organizations.userId }).from(organizations).where(eq(organizations.id, r.ngoId));
    await notify(tx, ngo.userId, "Your meals are on their way", `${quantity} portions of ${d.title} were collected. Confirm the actual quantity received after delivery.`);
    return p.id;
  });
}
export async function confirmDelivery(id: string, input: unknown, user: User, key: string) {
  authorize(user, ["ngo"], true);
  const { quantity, final } = confirmationInput.parse(input);
  return db.transaction(async (tx) => {
    const { d, r } = await lockedReservation(tx, id, user);
    if (r.ngoId !== user.organization?.id) throw new ApiError(403, "Only the receiving NGO can confirm delivery.");
    const fullKey = `delivery:${id}:${key}`;
    const [existing] = await tx.select().from(deliveries).where(eq(deliveries.idempotencyKey, fullKey));
    if (existing) { if (existing.quantity !== quantity) throw new ApiError(409, "This idempotency key was used for a different quantity."); return existing.id; }
    if (!r.pickupClosed || r.pickedQuantity === 0 || r.deliveryClosed || !["PICKED_UP", "PARTIALLY_DELIVERED"].includes(r.status)) throw new ApiError(409, "Complete pickup before confirming delivery. Closed deliveries cannot be changed.", "INVALID_TRANSITION");
    if (quantity > r.pickedQuantity - r.deliveredQuantity) throw new ApiError(409, `Only ${r.pickedQuantity - r.deliveredQuantity} collected portions remain to be delivered.`);
    const deliveredQuantity = r.deliveredQuantity + quantity, deliveryClosed = final || deliveredQuantity === r.pickedQuantity;
    const [delivery] = await tx.insert(deliveries).values({ reservationId: id, recipientId: user.id, quantity, idempotencyKey: fullKey }).returning();
    await tx.update(reservations).set({ deliveredQuantity, deliveryClosed, status: deliveryClosed ? "DELIVERED" : "PARTIALLY_DELIVERED" }).where(eq(reservations.id, id));
    await refreshStatus(tx, d.id);
    await audit(tx, user, "DELIVERY_CONFIRMED", "reservation", id, { quantity, final: deliveryClosed, undelivered: deliveryClosed ? r.pickedQuantity - deliveredQuantity : 0 });
    const [donor] = await tx.select({ userId: organizations.userId }).from(organizations).where(eq(organizations.id, d.donorId));
    await notify(tx, donor.userId, "A little extra made a difference", `${quantity} portions of ${d.title} were confirmed delivered to ${user.organization!.name}.`);
    return delivery.id;
  });
}
export async function getReservations(user: User): Promise<Reservation[]> {
  await sweepExpired();
  const ngo = organizations;
  const filters: SQL[] = [eq(donations.isDemo, user.isDemo)];
  if (user.role === "ngo") filters.push(eq(reservations.ngoId, user.organization!.id));
  else if (user.role === "donor") filters.push(eq(donations.donorId, user.organization!.id));
  else if (user.role === "volunteer") filters.push(eq(reservations.volunteerId, user.id));
  const rows = await db.select({ r: reservations, d: donations, ngo }).from(reservations).innerJoin(donations, eq(reservations.donationId, donations.id)).innerJoin(ngo, eq(reservations.ngoId, ngo.id)).where(and(...filters)).orderBy(desc(reservations.createdAt)).limit(200);
  const orgs = await db.select().from(organizations).where(eq(organizations.isDemo, user.isDemo));
  const volunteers = await db.select({ id: users.id, name: users.name }).from(users).where(and(eq(users.role, "volunteer"), eq(users.isDemo, user.isDemo)));
  return rows.map(({ r, d, ngo: n }) => { const donor = orgs.find((o) => o.id === d.donorId)!; return { ...r, ngoName: n.name, donorName: donor.name, volunteerName: volunteers.find((v) => v.id === r.volunteerId)?.name ?? null, expiresAt: r.expiresAt.toISOString(), createdAt: r.createdAt.toISOString(), donation: donationView(d, donor, user, true) }; });
}
export async function getImpact(user: User | null): Promise<Impact> {
  await sweepExpired();
  const demo = scope(user);
  const all = await db.select().from(donations).where(eq(donations.isDemo, demo));
  const reserved = await db.select({ r: reservations }).from(reservations).innerJoin(donations, eq(reservations.donationId, donations.id)).where(eq(donations.isDemo, demo));
  const collected = await db.select({ quantity: pickups.quantity }).from(pickups).innerJoin(reservations, eq(pickups.reservationId, reservations.id)).innerJoin(donations, eq(reservations.donationId, donations.id)).where(eq(donations.isDemo, demo));
  const delivered = await db.select({ id: deliveries.id, quantity: deliveries.quantity, confirmedAt: deliveries.confirmedAt, title: donations.title, org: organizations.name }).from(deliveries).innerJoin(reservations, eq(deliveries.reservationId, reservations.id)).innerJoin(donations, eq(reservations.donationId, donations.id)).innerJoin(organizations, eq(reservations.ngoId, organizations.id)).where(eq(donations.isDemo, demo)).orderBy(desc(deliveries.confirmedAt));
  const accounts = await db.select({ org: organizations, role: users.role }).from(organizations).innerJoin(users, eq(organizations.userId, users.id)).where(and(eq(organizations.isDemo, demo), eq(users.status, "active")));
  const active = all.filter((d) => d.deadline > new Date() && ["AVAILABLE", "PARTIALLY_RESERVED"].includes(d.status) && accounts.some((a) => a.role === "donor" && a.org.id === d.donorId && a.org.verification === "verified"));
  const weekly = Array.from({ length: 7 }, (_, i) => {
    const date = new Date(Date.now() - (6 - i) * 86400000).toISOString().slice(0, 10);
    return { date, day: new Date(`${date}T12:00:00Z`).toLocaleDateString("en", { weekday: "short" }), listed: all.filter((d) => d.createdAt.toISOString().startsWith(date)).reduce((n, d) => n + d.quantity, 0), delivered: delivered.filter((d) => d.confirmedAt.toISOString().startsWith(date)).reduce((n, d) => n + d.quantity, 0) };
  });
  return { listed: all.reduce((n, d) => n + d.quantity, 0), reserved: reserved.filter(({ r }) => !["CANCELLED", "EXPIRED", "DELIVERED"].includes(r.status)).reduce((n, { r }) => n + r.allocatedQuantity - r.pickedQuantity, 0), pickedUp: collected.reduce((n, p) => n + p.quantity, 0), delivered: delivered.reduce((n, d) => n + d.quantity, 0), completed: all.filter((d) => d.status === "DELIVERED").length, expired: all.filter((d) => d.status === "EXPIRED").length, cancelled: all.filter((d) => d.status === "CANCELLED").length, activeDonors: accounts.filter((a) => a.role === "donor" && a.org.verification === "verified").length, verifiedNgos: accounts.filter((a) => a.role === "ngo" && a.org.verification === "verified").length, available: active.reduce((n, d) => n + d.quantity - d.allocatedQuantity, 0), activeListings: active.length, weekly, history: delivered.slice(0, 50).map((d) => ({ id: d.id, title: d.title, organization: d.org, quantity: d.quantity, confirmedAt: d.confirmedAt.toISOString() })) };
}
