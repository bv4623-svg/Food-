import { randomBytes } from "node:crypto";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { users, organizations, donations, reservations, pickups, deliveries, auditLogs, notifications } from "@/db/schema";
import { DEMO_ENABLED, hashPassword } from "./security";

const id = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, "0")}`;
export const DEMO_USERS = { donor: id(1), donor2: id(2), ngo: id(3), ngo2: id(4), volunteer: id(5), admin: id(6) };
let initialized: Promise<void> | null = null;
export async function ensureSeed() {
  if (!DEMO_ENABLED) return;
  if (!initialized) initialized = seed().catch((error) => { initialized = null; throw error; });
  return initialized;
}
async function seed() {
  const passwordHash = await hashPassword(randomBytes(32).toString("hex"));
  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(743821)`);
    const [existing] = await tx.select({ id: users.id }).from(users).where(eq(users.id, id(1))).limit(1);
    if (existing) return;
    const accounts = [
      { n: 1, name: "Aarav Sharma", email: "campus@demo.refill.local", role: "donor" as const, org: "Campus Table", address: "Koramangala, Bengaluru", lat: 12.9352, lng: 77.6245 },
      { n: 2, name: "Riya Mehta", email: "greenspoon@demo.refill.local", role: "donor" as const, org: "Green Spoon Kitchen", address: "Indiranagar, Bengaluru", lat: 12.9784, lng: 77.6408 },
      { n: 3, name: "Ananya Rao", email: "neighbourhood@demo.refill.local", role: "ngo" as const, org: "Neighbourhood Kitchen", address: "HSR Layout, Bengaluru", lat: 12.9222, lng: 77.6278 },
      { n: 4, name: "Kabir Das", email: "hope@demo.refill.local", role: "ngo" as const, org: "Hope Pantry", address: "Jayanagar, Bengaluru", lat: 12.9255, lng: 77.5830 },
      { n: 5, name: "Maya Patel", email: "volunteer@demo.refill.local", role: "volunteer" as const, org: "Refill Volunteers", address: "Bengaluru, Karnataka", lat: 12.9716, lng: 77.5946 },
      { n: 6, name: "Demo Administrator", email: "admin@demo.refill.local", role: "admin" as const, org: "Refill Demo Administration", address: "Bengaluru, Karnataka", lat: 12.9716, lng: 77.5946 },
    ];
    for (const a of accounts) {
      await tx.insert(users).values({ id: id(a.n), email: a.email, name: a.name, role: a.role, passwordHash, isDemo: true });
      await tx.insert(organizations).values({ id: id(100 + a.n), userId: id(a.n), name: a.org, address: a.address, latitude: a.lat, longitude: a.lng, verification: "verified", capacity: a.n === 4 ? 60 : 120, maxDistanceKm: 20, isDemo: true });
    }
    const now = Date.now();
    const examples = [
      { title: "Vegetable biryani & raita", description: "Fragrant basmati rice with seasonal vegetables, served with cooling cucumber raita. Freshly prepared by our campus kitchen. Please bring clean, food-grade containers.", quantity: 40, category: "Cooked meals", dietary: "Vegetarian", image: "biryani", donor: 101, location: "Koramangala, Bengaluru", lat: 12.9352, lng: 77.6245, hours: 2.5 },
      { title: "Freshly baked artisan bread", description: "An assortment of freshly baked sourdough loaves and whole-wheat rolls from today's bake. Individually packed and ready to share.", quantity: 30, category: "Bakery", dietary: "Vegan", image: "bread", donor: 102, location: "Indiranagar, Bengaluru", lat: 12.9784, lng: 77.6408, hours: 4 },
      { title: "Dal, rice & seasonal sabzi", description: "A comforting, complete vegetarian meal with yellow dal, steamed rice and a seasonal vegetable curry. Kept warm in covered food-grade containers.", quantity: 55, category: "Cooked meals", dietary: "Vegetarian", image: "curry", donor: 101, location: "Koramangala, Bengaluru", lat: 12.9380, lng: 77.6230, hours: 3 },
      { title: "Garden-fresh salad bowls", description: "Colorful bowls of broccoli, bell peppers, cucumber and leafy greens. Dressing packed separately. Refrigerated since preparation.", quantity: 24, category: "Fresh produce", dietary: "Vegan", image: "salad", donor: 102, location: "Indiranagar, Bengaluru", lat: 12.9750, lng: 77.6410, hours: 1.5 },
      { title: "Homestyle vegetable curry", description: "Seasonal vegetable curry with steamed rice, packed in clean, covered containers. A hearty meal for your community.", quantity: 50, category: "Cooked meals", dietary: "Vegetarian", image: "curry", donor: 102, location: "Domlur, Bengaluru", lat: 12.9610, lng: 77.6380, hours: 5 },
      { title: "Whole-wheat breakfast rolls", description: "Fresh whole-wheat breakfast rolls, packed in batches of five. Contains wheat. Store in a clean, dry place and distribute today.", quantity: 20, category: "Bakery", dietary: "Vegetarian", image: "bread", donor: 101, location: "HSR Layout, Bengaluru", lat: 12.9150, lng: 77.6350, hours: 6 },
    ];
    for (let i = 0; i < examples.length; i++) {
      const e = examples[i];
      await tx.insert(donations).values({ id: id(201 + i), donorId: id(e.donor), title: e.title, description: e.description, category: e.category, dietary: e.dietary, quantity: e.quantity, preparedAt: new Date(now - 45 * 60000), storage: e.image === "salad" ? "Refrigerated below 5°C. Maintain cold chain during pickup." : "Covered, food-grade containers. Donor must confirm current temperature at pickup.", location: e.location, latitude: e.lat, longitude: e.lng, pickupFrom: new Date(now - 15 * 60000), deadline: new Date(now + e.hours * 3600000), instructions: "Meet the kitchen manager at the service entrance. Bring clean food-grade containers. Confirm handling conditions before collection.", imageUrl: `/images/${e.image}.jpg`, contact: "Kitchen manager (fictional demo contact)", isDemo: true, createdAt: new Date(now - i * 60000) });
    }
    const history = [40, 65, 35, 80, 55, 90, 70];
    for (let i = 0; i < history.length; i++) {
      const quantity = history[i];
      const time = new Date(now - (6 - i) * 86400000 - 3 * 3600000);
      const donationId = id(301 + i), reservationId = id(401 + i);
      await tx.insert(donations).values({ id: donationId, donorId: id(i % 2 ? 102 : 101), title: i % 2 ? "Community lunch portions" : "Campus kitchen meal portions", description: "Fictional historical donation seeded for the Refill demo. Not real-world impact.", category: "Cooked meals", dietary: "Vegetarian", quantity, allocatedQuantity: quantity, preparedAt: new Date(time.getTime() - 3600000), storage: "Covered containers (demo record)", location: "Bengaluru (demo)", latitude: 12.9352, longitude: 77.6245, pickupFrom: new Date(time.getTime() - 1800000), deadline: new Date(time.getTime() + 3600000), instructions: "Seeded demo activity", imageUrl: "/images/curry.jpg", status: "DELIVERED", isDemo: true, createdAt: new Date(time.getTime() - 3600000) });
      await tx.insert(reservations).values({ id: reservationId, donationId, ngoId: id(103), volunteerId: id(5), quantity, allocatedQuantity: quantity, pickedQuantity: quantity, deliveredQuantity: quantity, pickupClosed: true, deliveryClosed: true, status: "DELIVERED", expiresAt: new Date(time.getTime() + 3600000), createdAt: new Date(time.getTime() - 1800000) });
      await tx.insert(pickups).values({ reservationId, volunteerId: id(5), quantity, idempotencyKey: `seed-pickup-${i}`, confirmedAt: time });
      await tx.insert(deliveries).values({ reservationId, recipientId: id(3), quantity, idempotencyKey: `seed-delivery-${i}`, confirmedAt: new Date(time.getTime() + 1800000) });
      await tx.insert(auditLogs).values({ actorId: id(3), action: "DEMO_DELIVERY_SEEDED", entity: "reservation", entityId: reservationId, metadata: { quantity, fictional: true }, isDemo: true, createdAt: time });
    }
    for (const a of accounts) await tx.insert(notifications).values({ userId: id(a.n), title: "Welcome to your demo workspace", message: "These organizations and historical transactions are fictional. New donations and confirmations are saved to the real database." });
  });
}
