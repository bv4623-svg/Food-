import { pgTable, pgEnum, uuid, text, integer, timestamp, boolean, doublePrecision, jsonb, index, check, uniqueIndex } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const roleEnum = pgEnum("user_role", ["donor", "ngo", "volunteer", "admin"]);
export const verificationEnum = pgEnum("verification_status", ["pending", "verified", "rejected"]);
export const donationStatusEnum = pgEnum("donation_status", ["AVAILABLE", "PARTIALLY_RESERVED", "RESERVED", "PICKED_UP", "DELIVERED", "EXPIRED", "CANCELLED"]);
export const reservationStatusEnum = pgEnum("reservation_status", ["RESERVED", "PARTIALLY_PICKED_UP", "PICKED_UP", "PARTIALLY_DELIVERED", "DELIVERED", "EXPIRED", "CANCELLED"]);
const date = (name: string) => timestamp(name, { withTimezone: true, mode: "date" });

export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  passwordHash: text("password_hash").notNull(),
  role: roleEnum("role").notNull(),
  status: text("status").notNull().default("active"),
  isDemo: boolean("is_demo").notNull().default(false),
  createdAt: date("created_at").notNull().defaultNow(),
});

export const organizations = pgTable("organizations", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().unique().references(() => users.id),
  name: text("name").notNull(),
  address: text("address").notNull(),
  phone: text("phone").notNull().default(""),
  latitude: doublePrecision("latitude").notNull().default(12.9716),
  longitude: doublePrecision("longitude").notNull().default(77.5946),
  verification: verificationEnum("verification").notNull().default("pending"),
  verificationDetails: text("verification_details"),
  capacity: integer("capacity").notNull().default(100),
  maxDistanceKm: doublePrecision("max_distance_km").notNull().default(20),
  dietaryPreferences: text("dietary_preferences").array().notNull().default(sql`ARRAY['Vegetarian','Vegan','Contains meat']::text[]`),
  collectionStartHour: integer("collection_start_hour").notNull().default(0),
  collectionEndHour: integer("collection_end_hour").notNull().default(24),
  isDemo: boolean("is_demo").notNull().default(false),
  createdAt: date("created_at").notNull().defaultNow(),
}, (t) => [check("valid_org_coordinates", sql`${t.latitude} BETWEEN -90 AND 90 AND ${t.longitude} BETWEEN -180 AND 180`), check("valid_org_capacity", sql`${t.capacity} > 0`), check("valid_collection_hours", sql`${t.collectionStartHour} >= 0 AND ${t.collectionEndHour} <= 24 AND ${t.collectionStartHour} < ${t.collectionEndHour}`)]);

export const sessions = pgTable("sessions", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  tokenHash: text("token_hash").notNull().unique(),
  expiresAt: date("expires_at").notNull(),
  createdAt: date("created_at").notNull().defaultNow(),
}, (t) => [index("session_user_idx").on(t.userId)]);

export const donations = pgTable("donations", {
  id: uuid("id").defaultRandom().primaryKey(),
  donorId: uuid("donor_id").notNull().references(() => organizations.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  dietary: text("dietary").notNull(),
  quantity: integer("quantity").notNull(),
  allocatedQuantity: integer("allocated_quantity").notNull().default(0),
  preparedAt: date("prepared_at").notNull(),
  plannedPreparation: boolean("planned_preparation").notNull().default(false),
  storage: text("storage").notNull(),
  location: text("location").notNull(),
  latitude: doublePrecision("latitude").notNull(),
  longitude: doublePrecision("longitude").notNull(),
  pickupFrom: date("pickup_from").notNull(),
  deadline: date("deadline").notNull(),
  instructions: text("instructions").notNull(),
  contact: text("contact").notNull().default(""),
  imageUrl: text("image_url"),
  status: donationStatusEnum("status").notNull().default("AVAILABLE"),
  isDemo: boolean("is_demo").notNull().default(false),
  createdAt: date("created_at").notNull().defaultNow(),
}, (t) => [check("valid_meal_quantity", sql`${t.quantity} > 0 AND ${t.allocatedQuantity} >= 0 AND ${t.allocatedQuantity} <= ${t.quantity}`), check("valid_donation_times", sql`${t.deadline} > ${t.pickupFrom}`), check("valid_donation_coordinates", sql`${t.latitude} BETWEEN -90 AND 90 AND ${t.longitude} BETWEEN -180 AND 180`), index("donation_deadline_idx").on(t.deadline), index("donation_donor_idx").on(t.donorId)]);

export const reservations = pgTable("reservations", {
  id: uuid("id").defaultRandom().primaryKey(),
  donationId: uuid("donation_id").notNull().references(() => donations.id),
  ngoId: uuid("ngo_id").notNull().references(() => organizations.id),
  volunteerId: uuid("volunteer_id").references(() => users.id),
  quantity: integer("quantity").notNull(),
  allocatedQuantity: integer("allocated_quantity").notNull(),
  pickedQuantity: integer("picked_quantity").notNull().default(0),
  deliveredQuantity: integer("delivered_quantity").notNull().default(0),
  pickupClosed: boolean("pickup_closed").notNull().default(false),
  deliveryClosed: boolean("delivery_closed").notNull().default(false),
  status: reservationStatusEnum("status").notNull().default("RESERVED"),
  expiresAt: date("expires_at").notNull(),
  createdAt: date("created_at").notNull().defaultNow(),
}, (t) => [check("valid_reservation_quantities", sql`${t.quantity} > 0 AND ${t.allocatedQuantity} >= 0 AND ${t.allocatedQuantity} <= ${t.quantity} AND ${t.pickedQuantity} >= 0 AND ${t.pickedQuantity} <= ${t.allocatedQuantity} AND ${t.deliveredQuantity} >= 0 AND ${t.deliveredQuantity} <= ${t.pickedQuantity}`), index("reservation_donation_idx").on(t.donationId), index("reservation_ngo_idx").on(t.ngoId), index("reservation_expiry_idx").on(t.expiresAt)]);

export const pickups = pgTable("pickups", {
  id: uuid("id").defaultRandom().primaryKey(),
  reservationId: uuid("reservation_id").notNull().references(() => reservations.id),
  volunteerId: uuid("volunteer_id").notNull().references(() => users.id),
  quantity: integer("quantity").notNull(),
  idempotencyKey: text("idempotency_key").notNull().unique(),
  confirmedAt: date("confirmed_at").notNull().defaultNow(),
}, (t) => [check("positive_pickup_quantity", sql`${t.quantity} > 0`)]);

export const deliveries = pgTable("deliveries", {
  id: uuid("id").defaultRandom().primaryKey(),
  reservationId: uuid("reservation_id").notNull().references(() => reservations.id),
  recipientId: uuid("recipient_id").notNull().references(() => users.id),
  quantity: integer("quantity").notNull(),
  idempotencyKey: text("idempotency_key").notNull().unique(),
  confirmedAt: date("confirmed_at").notNull().defaultNow(),
}, (t) => [check("positive_delivery_quantity", sql`${t.quantity} > 0`)]);

export const auditLogs = pgTable("audit_logs", {
  id: uuid("id").defaultRandom().primaryKey(),
  actorId: uuid("actor_id").references(() => users.id),
  action: text("action").notNull(),
  entity: text("entity").notNull(),
  entityId: uuid("entity_id"),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default({}),
  isDemo: boolean("is_demo").notNull().default(false),
  createdAt: date("created_at").notNull().defaultNow(),
}, (t) => [index("audit_created_idx").on(t.createdAt)]);

export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id),
  tokenHash: text("token_hash").notNull().unique(),
  expiresAt: date("expires_at").notNull(),
  usedAt: date("used_at"),
});

export const notifications = pgTable("notifications", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  message: text("message").notNull(),
  read: boolean("read").notNull().default(false),
  createdAt: date("created_at").notNull().defaultNow(),
});

export const media = pgTable("media", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id),
  mimeType: text("mime_type").notNull(),
  data: text("data").notNull(),
  createdAt: date("created_at").notNull().defaultNow(),
});

export const reports = pgTable("reports", {
  id: uuid("id").defaultRandom().primaryKey(),
  reporterId: uuid("reporter_id").notNull().references(() => users.id),
  donationId: uuid("donation_id").notNull().references(() => donations.id),
  reason: text("reason").notNull(),
  status: text("status").notNull().default("open"),
  resolution: text("resolution"),
  resolvedBy: uuid("resolved_by").references(() => users.id),
  isDemo: boolean("is_demo").notNull().default(false),
  createdAt: date("created_at").notNull().defaultNow(),
  resolvedAt: date("resolved_at"),
}, (t) => [index("report_status_idx").on(t.status), check("valid_report_status", sql`${t.status} IN ('open', 'reviewed')`)]);
