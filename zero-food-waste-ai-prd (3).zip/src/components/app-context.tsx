"use client";
import { createContext, useContext } from "react";
import type { Bootstrap, Impact } from "@/lib/types";
export interface AppContextValue extends Bootstrap {
  impact: Impact | null; revision: number; refresh: () => Promise<void>;
  openDemo: (destination?: string, preferredRole?: string) => void;
  toast: (message: string, error?: boolean) => void; shareFood: () => void;
}
export const AppContext = createContext<AppContextValue | null>(null);
export function useApp() { const value = useContext(AppContext); if (!value) throw new Error("Workspace context is missing"); return value; }
