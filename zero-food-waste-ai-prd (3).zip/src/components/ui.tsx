"use client";
import { useEffect, useId, useRef, useState, type ReactNode } from "react";
import Link from "next/link";
import { AlertCircle, ArrowRight, CheckCircle2, Leaf, LoaderCircle, X } from "lucide-react";
import { api } from "@/lib/client";
import { useApp } from "./app-context";
export function Modal({ title, children, onClose, wide = false }: { title: string; children: ReactNode; onClose: () => void; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null), id = useId();
  const closeRef = useRef(onClose); closeRef.current = onClose;
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow; document.body.style.overflow = "hidden";
    const focusable = () => Array.from(ref.current?.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], input:not([disabled]), select, textarea, [tabindex="0"]') ?? []).filter((el) => el.offsetParent !== null);
    focusable()[0]?.focus();
    const key = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeRef.current();
      if (event.key === "Tab") { const items = focusable(), first = items[0], last = items.at(-1); if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); } else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); } }
    };
    document.addEventListener("keydown", key);
    return () => { document.body.style.overflow = overflow; document.removeEventListener("keydown", key); previous?.focus(); };
  }, []);
  return <div className="modal-backdrop" onClick={onClose}><div ref={ref} className={`modal ${wide ? "modal-wide" : ""}`} role="dialog" aria-modal="true" aria-labelledby={id} onClick={(e) => e.stopPropagation()}><div className="modal-title"><h2 id={id}>{title}</h2><button className="icon-button" onClick={onClose} aria-label="Close dialog"><X size={20} /></button></div>{children}</div></div>;
}
export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) { return <div className="error-box" role="alert"><AlertCircle size={19} /><div><p>{message}</p>{onRetry && <button className="text-button" onClick={onRetry}>Try again <ArrowRight size={14} /></button>}</div></div>; }
export function Notice({ children, success = false }: { children: ReactNode; success?: boolean }) { return <div className={`notice ${success ? "notice-success" : ""}`}>{success ? <CheckCircle2 size={19} /> : <Leaf size={19} />}<div>{children}</div></div>; }
export function Loading({ text = "Gathering the good stuff…" }: { text?: string }) { return <div className="loading-state" role="status"><LoaderCircle className="spin" size={25} /><p>{text}</p></div>; }
export function EmptyState({ title, description, children }: { title: string; description: string; children?: ReactNode }) { return <div className="empty-state"><div className="empty-icon"><Leaf size={30} /></div><h3>{title}</h3><p>{description}</p>{children}</div>; }
export function PageHeading({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description: string; action?: ReactNode }) { return <div className="page-heading"><div>{eyebrow && <p className="eyebrow">{eyebrow}</p>}<h1>{title}</h1><p className="page-description">{description}</p></div>{action}</div>; }
export function StatusBadge({ status }: { status: string }) { const color = ["DELIVERED", "verified", "active", "AVAILABLE"].includes(status) ? "green" : ["CANCELLED", "EXPIRED", "rejected", "suspended"].includes(status) ? "gray" : "orange"; return <span className={`status-badge ${color}`}><span />{status.replace(/_/g, " ").toLowerCase()}</span>; }
export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) { return <label className="field"><span className="field-label">{label}</span>{children}{hint && <span className="field-hint">{hint}</span>}</label>; }
export function useData<T>(path: string | null) {
  const { revision } = useApp();
  const [data, setData] = useState<T | null>(null), [error, setError] = useState(""), [loading, setLoading] = useState(true), [reload, setReload] = useState(0);
  useEffect(() => { let active = true; if (!path) { setLoading(false); setData(null); return; } setLoading(true); setError(""); api<T>(path).then((result) => { if (active) setData(result); }).catch((e) => { if (active) setError(e.message); }).finally(() => { if (active) setLoading(false); }); return () => { active = false; }; }, [path, revision, reload]);
  return { data, error, loading, retry: () => setReload((n) => n + 1) };
}
export function SubmitLabel({ loading, children }: { loading: boolean; children: ReactNode }) { return <>{loading ? <LoaderCircle size={17} className="spin" /> : null}{loading ? "Please wait…" : children}</>; }
