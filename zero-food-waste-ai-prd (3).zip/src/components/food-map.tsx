"use client";
import { useEffect, useRef, useState } from "react";
import type { Donation } from "@/lib/types";
import "leaflet/dist/leaflet.css";
import { ErrorBox } from "./ui";
export default function FoodMap({ donations }: { donations: Donation[] }) {
  const ref = useRef<HTMLDivElement>(null), [error, setError] = useState("");
  useEffect(() => {
    let active = true; let map: import("leaflet").Map | undefined;
    import("leaflet").then((L) => {
      if (!active || !ref.current) return;
      const valid = donations.filter((d) => Number.isFinite(d.latitude) && Number.isFinite(d.longitude) && Math.abs(d.latitude) <= 90 && Math.abs(d.longitude) <= 180);
      if (!valid.length) { setError("No valid coordinates are available for these listings."); return; }
      map = L.map(ref.current).setView([valid[0].latitude, valid[0].longitude], 13);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' }).addTo(map);
      const icon = L.divIcon({ className: "map-marker", iconSize: [28, 28], iconAnchor: [14, 14] });
      const points: [number, number][] = [];
      for (const d of valid) {
        points.push([d.latitude, d.longitude]);
        const popup = document.createElement("div"), title = document.createElement("strong"), info = document.createElement("p"), link = document.createElement("a");
        title.textContent = d.title; info.textContent = `${d.availableQuantity} portions · ${d.donorName}${d.isDemo ? " (fictional demo)" : ""}`; link.href = `/donations/${d.id}`; link.textContent = "View donation →"; popup.append(title, info, link);
        L.marker([d.latitude, d.longitude], { icon }).addTo(map).bindPopup(popup);
      }
      if (points.length > 1) map.fitBounds(L.latLngBounds(points), { padding: [45, 45], maxZoom: 14 });
      setTimeout(() => map?.invalidateSize(), 100);
    }).catch(() => setError("The map could not load. Listing addresses are still available; please retry with a network connection."));
    return () => { active = false; map?.remove(); };
  }, [donations]);
  return <>{error && <ErrorBox message={error} />}<div ref={ref} className="map-container" aria-label="Map of donation pickup locations" /></>;
}
