import { handler } from "@/lib/api-handler";
export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export const GET = handler;
export const POST = handler;
export const PATCH = handler;
