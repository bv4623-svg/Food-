import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
export const metadata: Metadata = {
  title: "Refill — Good food. Better shared.",
  description: "Connect surplus food with people who need it. A transparent, database-backed food sharing workspace for donors, NGOs and volunteers.",
  icons: { icon: "/icon.svg" },
};
export default function RootLayout({ children }: { children: ReactNode }) { return <html lang="en"><body>{children}</body></html>; }
