import RefillApp from "@/components/refill-app";
export default function HomePage() { return <RefillApp />; }
