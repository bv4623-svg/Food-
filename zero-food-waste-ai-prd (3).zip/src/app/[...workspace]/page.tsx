import RefillApp from "@/components/refill-app";
export default function WorkspacePage() { return <RefillApp />; }
