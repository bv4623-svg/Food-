import { test, expect, type APIRequestContext, type PlaywrightWorkerArgs } from "@playwright/test";
type Playwright = PlaywrightWorkerArgs["playwright"];
import { createHash, randomBytes } from "node:crypto";
import { and, eq, ilike, inArray, or } from "drizzle-orm";
import sharp from "sharp";
import { db, pool } from "@/db";
import { auditLogs, deliveries, donations, media, notifications, organizations, passwordResetTokens, pickups, reports, reservations, sessions, users } from "@/db/schema";
import type { Bootstrap, Donation, Impact, User } from "@/lib/types";

const baseURL = process.env.BASE_URL ?? "http://127.0.0.1:3000";
const prefix = `E2E-${Date.now()}-${randomBytes(3).toString("hex")}`;
const testPassword = `Refill9${randomBytes(12).toString("hex")}`;
let count = 0;
const contexts: APIRequestContext[] = [], tokens: string[] = [], uploaded: string[] = [];
const hash = (value: string) => createHash("sha256").update(value).digest("hex");
const payload = (title = `${prefix} ${++count} vegetable meals`, extra: Record<string, unknown> = {}) => ({ title, description: "Freshly prepared vegetable rice for the automated fictional donation test.", category: "Cooked meals", dietary: "Vegetarian", quantity: 40, preparedAt: new Date(Date.now() - 45 * 60000).toISOString(), plannedPreparation: false, storage: "Covered food-grade containers; confirm temperature with the donor at pickup.", location: "Koramangala, Bengaluru", latitude: 12.9352, longitude: 77.6245, pickupFrom: new Date(Date.now() - 5 * 60000).toISOString(), deadline: new Date(Date.now() + 3 * 3600000).toISOString(), instructions: "Meet the test kitchen manager. Bring clean food-grade containers.", contact: "Fictional test kitchen manager", imageUrl: null, ...extra });
async function context(playwright: Playwright, role?: string) {
  const c = await playwright.request.newContext({ baseURL, extraHTTPHeaders: { Origin: baseURL } }); contexts.push(c);
  if (role) { const response = await c.post("/api/v1/auth/demo", { data: { role } }); expect(response.status(), await response.text()).toBe(200); const state = await c.storageState(); for (const cookie of state.cookies) if (cookie.name === "refill_session") tokens.push(hash(cookie.value)); }
  return c;
}
async function create(c: APIRequestContext, extra: Record<string, unknown> = {}) { const response = await c.post("/api/v1/donations", { data: payload(undefined, extra) }); expect(response.status(), await response.text()).toBe(201); return await response.json() as Donation; }
async function reserve(c: APIRequestContext, id: string, quantity: number) { return c.post(`/api/v1/donations/${id}/reservations`, { data: { quantity } }); }
async function confirm(c: APIRequestContext, kind: "pickups" | "deliveries", id: string, quantity: number, final = true, key = randomBytes(12).toString("hex")) { return c.post(`/api/v1/${kind}/${id}/confirm`, { data: { quantity, final }, headers: { "Idempotency-Key": key } }); }
async function impact(c: APIRequestContext) { return (await (await c.get("/api/v1/dashboard/impact")).json()) as Impact; }
async function cleanup() {
  const ds = await db.select({ id: donations.id }).from(donations).where(ilike(donations.title, `${prefix}%`)); const ids = ds.map((d) => d.id);
  const rs = ids.length ? await db.select({ id: reservations.id }).from(reservations).where(inArray(reservations.donationId, ids)) : []; const rids = rs.map((r) => r.id);
  const reportRows = ids.length ? await db.select({ id: reports.id }).from(reports).where(inArray(reports.donationId, ids)) : [];
  const testUsers = await db.select({ id: users.id }).from(users).where(ilike(users.email, `${prefix.toLowerCase()}%`)); const uids = testUsers.map((u) => u.id);
  const entities = [...ids, ...rids, ...reportRows.map((r) => r.id), ...uids];
  await db.transaction(async (tx) => {
    if (entities.length) await tx.delete(auditLogs).where(or(inArray(auditLogs.entityId, entities), uids.length ? inArray(auditLogs.actorId, uids) : undefined));
    if (rids.length) { await tx.delete(deliveries).where(inArray(deliveries.reservationId, rids)); await tx.delete(pickups).where(inArray(pickups.reservationId, rids)); await tx.delete(reservations).where(inArray(reservations.id, rids)); }
    if (ids.length) { await tx.delete(reports).where(inArray(reports.donationId, ids)); await tx.delete(donations).where(inArray(donations.id, ids)); }
    await tx.delete(notifications).where(ilike(notifications.message, `%${prefix}%`));
    if (uploaded.length) await tx.delete(media).where(inArray(media.id, uploaded));
    if (tokens.length) await tx.delete(sessions).where(inArray(sessions.tokenHash, tokens));
    if (uids.length) { await tx.delete(notifications).where(inArray(notifications.userId, uids)); await tx.delete(sessions).where(inArray(sessions.userId, uids)); await tx.delete(passwordResetTokens).where(inArray(passwordResetTokens.userId, uids)); await tx.delete(media).where(inArray(media.userId, uids)); await tx.delete(organizations).where(inArray(organizations.userId, uids)); await tx.delete(users).where(inArray(users.id, uids)); }
  });
}
test.afterEach(async ({ page }) => { const state = await page.context().storageState(); for (const cookie of state.cookies) if (cookie.name === "refill_session") tokens.push(hash(cookie.value)); for (const c of contexts.splice(0)) await c.dispose(); await cleanup(); tokens.length = 0; uploaded.length = 0; });
test.afterAll(async () => { await pool.end(); });

test("40-meal listing persists; 25 reserved leaves 15 and cannot oversell", async ({ playwright }) => {
  const donor = await context(playwright, "donor"), ngo = await context(playwright, "ngo"), second = await context(playwright, "ngo2"), publicClient = await context(playwright);
  const d = await create(donor); const persisted = await (await donor.get(`/api/v1/donations/${d.id}`)).json(); expect(persisted.quantity).toBe(40);
  const listing = await (await ngo.get(`/api/v1/donations?search=${encodeURIComponent(d.title)}`)).json(); expect(listing.data.some((x: Donation) => x.id === d.id)).toBeTruthy();
  const matches = await (await donor.get(`/api/v1/matches/${d.id}`)).json(); expect(matches.data.length).toBeGreaterThan(0); for (const match of matches.data) { expect(match.reasons).toContain("Verified organization"); expect(match.capacity).toBeGreaterThan(0); expect(match.reasons.length).toBe(5); }
  const publicD = await (await publicClient.get(`/api/v1/donations/${d.id}`)).json(); expect(publicD.instructions).toBeUndefined(); expect(publicD.contact).toBeUndefined();
  const r = await reserve(ngo, d.id, 25); expect(r.status()).toBe(201); expect((await r.json()).donation.availableQuantity).toBe(15);
  const tooMany = await reserve(second, d.id, 16); expect(tooMany.status()).toBe(409); expect((await tooMany.json()).error.message).toContain("15");
  expect((await (await donor.get(`/api/v1/donations/${d.id}`)).json()).availableQuantity).toBe(15);
});

test("simultaneous NGO requests are serialized and cannot oversell", async ({ playwright }) => {
  const donor = await context(playwright, "donor"), ngo = await context(playwright, "ngo"), second = await context(playwright, "ngo2"); const d = await create(donor);
  const responses = await Promise.all([reserve(ngo, d.id, 25), reserve(second, d.id, 25)]); expect(responses.map((r) => r.status()).sort()).toEqual([201, 409]);
  const actual = await (await donor.get(`/api/v1/donations/${d.id}`)).json(); expect(actual.allocatedQuantity).toBe(25); expect(actual.availableQuantity).toBe(15);
});

test("cancellation releases exactly once; expired holds release and reject new claims", async ({ playwright }) => {
  const donor = await context(playwright, "donor"), ngo = await context(playwright, "ngo"); const d = await create(donor);
  const r = await (await reserve(ngo, d.id, 25)).json(); expect((await ngo.post(`/api/v1/reservations/${r.id}/cancel`, { data: {} })).status()).toBe(200); expect((await ngo.post(`/api/v1/reservations/${r.id}/cancel`, { data: {} })).status()).toBe(200);
  expect((await (await donor.get(`/api/v1/donations/${d.id}`)).json()).availableQuantity).toBe(40);
  const expiring = await create(donor, { deadline: new Date(Date.now() + 2500).toISOString() }); const hold = await reserve(ngo, expiring.id, 10); expect(hold.status()).toBe(201);
  await new Promise((resolve) => setTimeout(resolve, 3000)); const expired = await (await donor.get(`/api/v1/donations/${expiring.id}`)).json(); expect(expired.status).toBe("EXPIRED"); expect(expired.allocatedQuantity).toBe(0); expect((await reserve(ngo, expiring.id, 1)).status()).toBe(409);
});

test("partial pickup/delivery, ownership checks and invalid transitions", async ({ playwright }) => {
  const donor = await context(playwright, "donor"), otherDonor = await context(playwright, "donor2"), ngo = await context(playwright, "ngo"), otherNgo = await context(playwright, "ngo2"), volunteer = await context(playwright, "volunteer");
  const baseline = await impact(donor), d = await create(donor); const r = await (await reserve(ngo, d.id, 40)).json();
  expect((await donor.patch(`/api/v1/donations/${d.id}`, { data: payload(d.title, { quantity: 39 }) })).status()).toBe(409);
  expect((await donor.patch(`/api/v1/donations/${d.id}`, { data: { status: "CANCELLED" } })).status()).toBe(409);
  expect((await otherDonor.patch(`/api/v1/donations/${d.id}`, { data: payload(d.title) })).status()).toBe(403);
  expect((await confirm(ngo, "pickups", r.id, 40)).status()).toBe(403);
  expect((await confirm(ngo, "deliveries", r.id, 10)).status()).toBe(409);
  expect((await otherNgo.post(`/api/v1/reservations/${r.id}/cancel`, { data: {} })).status()).toBe(403);
  expect((await confirm(volunteer, "pickups", r.id, 20, false)).status()).toBe(200);
  const secondPickup = await confirm(volunteer, "pickups", r.id, 10, true, "partial-pickup-key"); expect(secondPickup.status()).toBe(200);
  expect((await confirm(volunteer, "pickups", r.id, 10, true, "partial-pickup-key")).status()).toBe(200);
  expect((await (await donor.get(`/api/v1/donations/${d.id}`)).json()).availableQuantity).toBe(10);
  expect((await confirm(otherNgo, "deliveries", r.id, 10)).status()).toBe(403);
  expect((await confirm(ngo, "deliveries", r.id, 20, false)).status()).toBe(200); expect((await confirm(ngo, "deliveries", r.id, 5, true, "partial-delivery-key")).status()).toBe(200);
  expect((await confirm(ngo, "deliveries", r.id, 5, true, "partial-delivery-key")).status()).toBe(200); expect((await confirm(ngo, "deliveries", r.id, 4, true, "partial-delivery-key")).status()).toBe(409);
  expect((await impact(donor)).delivered).toBe(baseline.delivered + 25);
});

test("35 received of 40 picked up counts 35; retries never double count", async ({ playwright }) => {
  const donor = await context(playwright, "donor"), ngo = await context(playwright, "ngo"), volunteer = await context(playwright, "volunteer"); const baseline = await impact(donor), d = await create(donor), r = await (await reserve(ngo, d.id, 40)).json();
  expect((await confirm(volunteer, "pickups", r.id, 40)).status()).toBe(200); const first = await confirm(ngo, "deliveries", r.id, 35, true, "thirty-five-delivered"); expect(first.status()).toBe(200); const firstId = (await first.json()).id;
  const retry = await confirm(ngo, "deliveries", r.id, 35, true, "thirty-five-delivered"); expect(retry.status()).toBe(200); expect((await retry.json()).id).toBe(firstId);
  expect((await impact(donor)).delivered).toBe(baseline.delivered + 35); expect((await confirm(ngo, "deliveries", r.id, 5)).status()).toBe(409);
});

test("registration is unverified until actual admin review; logout invalidates sessions", async ({ playwright }) => {
  const c = await context(playwright), admin = await context(playwright, "admin"); const email = `${prefix.toLowerCase()}-donor@example.test`;
  const registered = await c.post("/api/v1/auth/register", { data: { email, password: testPassword, name: "Fictional Test Donor", role: "donor", organizationName: `${prefix} Test Kitchen`, address: "Koramangala, Bengaluru", phone: "Fictional contact" } }); expect(registered.status()).toBe(201); const u = (await registered.json()).user;
  expect(u.organization.verification).toBe("pending"); expect((await c.post("/api/v1/donations", { data: payload() })).status()).toBe(403);
  expect((await c.post("/api/v1/organizations/me/verification", { data: { details: "Fictional verification details provided only for this automated test." } })).status()).toBe(200);
  const pending = await (await admin.get("/api/v1/admin/organizations/pending")).json(); expect(pending.data.some((x: { user: User }) => x.user.id === u.id)).toBeTruthy();
  expect((await admin.patch(`/api/v1/admin/organizations/${u.organization.id}/verification`, { data: { verification: "verified" } })).status()).toBe(200); await create(c);
  expect((await c.post("/api/v1/auth/logout", { data: {} })).status()).toBe(200); expect((await c.get("/api/v1/users/me")).status()).toBe(401);
  expect((await c.post("/api/v1/auth/login", { data: { email, password: "wrong-password" } })).status()).toBe(401); expect((await c.post("/api/v1/auth/login", { data: { email, password: testPassword } })).status()).toBe(200);
  const b = await (await c.get("/api/v1/bootstrap")).json(); if (!b.emailConfigured) { const reset = await c.post("/api/v1/auth/forgot-password", { data: { email } }); expect(reset.status()).toBe(503); expect((await reset.json()).error.message).toContain("not configured"); }
});

test("unverified NGOs are excluded and capacity is enforced inside the transaction", async ({ playwright }) => {
  const donor = await context(playwright, "donor"), admin = await context(playwright, "admin"), c = await context(playwright); const d = await create(donor);
  const registered = await c.post("/api/v1/auth/register", { data: { email: `${prefix.toLowerCase()}-ngo@example.test`, password: testPassword, name: "Fictional NGO Manager", role: "ngo", organizationName: `${prefix} Small NGO`, address: "Koramangala, Bengaluru", phone: "Fictional contact" } }); expect(registered.status()).toBe(201); const u = (await registered.json()).user;
  let matches = await (await donor.get(`/api/v1/matches/${d.id}`)).json(); expect(matches.data.some((x: { id: string }) => x.id === u.organization.id)).toBeFalsy();
  expect((await c.patch("/api/v1/organizations/me", { data: { name: u.organization.name, address: u.organization.address, phone: "Fictional contact", latitude: 12.9352, longitude: 77.6245, capacity: 5, maxDistanceKm: 20, dietaryPreferences: ["Vegetarian"], collectionStartHour: 0, collectionEndHour: 24 } })).status()).toBe(200);
  expect((await admin.patch(`/api/v1/admin/organizations/${u.organization.id}/verification`, { data: { verification: "verified" } })).status()).toBe(200);
  matches = await (await donor.get(`/api/v1/matches/${d.id}`)).json(); const match = matches.data.find((x: { id: string }) => x.id === u.organization.id); expect(match.capacity).toBe(5);
  expect((await reserve(c, d.id, 6)).status()).toBe(409); expect((await reserve(c, d.id, 5)).status()).toBe(201);
  expect((await c.patch("/api/v1/users/me", { data: { status: "suspended" } })).status()).toBe(409);
});

test("AI unavailable does not block reservations; cross-origin writes are rejected", async ({ playwright }) => {
  const donor = await context(playwright, "donor"), ngo = await context(playwright, "ngo"), publicClient = await context(playwright); const d = await create(donor);
  const b = await (await donor.get("/api/v1/bootstrap")).json() as Bootstrap;
  if (!b.aiConfigured) { const ai = await donor.post("/api/v1/ai/listing-assistant", { data: { donationId: d.id } }); expect(ai.status()).toBe(503); expect((await ai.json()).error.message).toContain("not configured"); }
  expect((await reserve(ngo, d.id, 25)).status()).toBe(201);
  expect((await donor.post("/api/v1/donations", { data: payload(), headers: { Origin: "https://untrusted.example" } })).status()).toBe(403); expect((await publicClient.get("/api/v1/admin/accounts")).status()).toBe(401);
  expect((await donor.post("/api/v1/donations", { data: payload(undefined, { quantity: 0 }) })).status()).toBe(422); expect((await donor.post("/api/v1/donations", { data: payload(undefined, { preparedAt: new Date(Date.now() + 3600000).toISOString() }) })).status()).toBe(422);
});

test("uploads decode actual content; media cannot be attached by another donor", async ({ playwright }) => {
  const donor = await context(playwright, "donor"), other = await context(playwright, "donor2");
  const invalid = await donor.post("/api/v1/uploads", { multipart: { image: { name: "fake.png", mimeType: "image/png", buffer: Buffer.from("not a valid image, even with a png name") } } }); expect(invalid.status()).toBe(400);
  const png = await sharp({ create: { width: 80, height: 80, channels: 3, background: "#84a66c" } }).png().toBuffer(); const valid = await donor.post("/api/v1/uploads", { multipart: { image: { name: "meal.png", mimeType: "image/png", buffer: png } } }); expect(valid.status()).toBe(201); const url = (await valid.json()).url; uploaded.push(url.split("/").at(-1));
  const image = await donor.get(url); expect(image.headers()["content-type"]).toBe("image/jpeg"); expect((await other.post("/api/v1/donations", { data: payload(undefined, { imageUrl: url }) })).status()).toBe(400);
  await create(donor, { imageUrl: url });
});

test("concerns persist and require an admin to record a review", async ({ playwright }) => {
  const donor = await context(playwright, "donor"), ngo = await context(playwright, "ngo"), admin = await context(playwright, "admin"); const d = await create(donor);
  const reported = await ngo.post("/api/v1/reports", { data: { donationId: d.id, reason: "Fictional automated concern about pickup instructions needing clarification." } }); expect(reported.status()).toBe(201); const id = (await reported.json()).id;
  expect((await ngo.get("/api/v1/admin/reports")).status()).toBe(403); const queue = await (await admin.get("/api/v1/admin/reports")).json(); expect(queue.data.some((x: { report: { id: string } }) => x.report.id === id)).toBeTruthy();
  expect((await admin.patch(`/api/v1/admin/reports/${id}`, { data: { resolution: "Fictional review completed; pickup details clarified with the donor." } })).status()).toBe(200);
});

test("responsive workspace components: search, save, filters, map and keyboard dialogs", async ({ page }) => {
  const errors: string[] = []; page.on("pageerror", (e) => errors.push(e.message)); await page.goto("/"); await expect(page.locator(".donation-card")).toHaveCount(3); await expect(page.getByRole("heading", { name: "Good food. Better shared." })).toBeVisible();
  await page.screenshot({ path: "artifacts/refill-overview-desktop.png", fullPage: true });
  await page.getByRole("link", { name: "Food marketplace", exact: true }).click(); await page.getByLabel("Search food, organization or location").fill("biryani"); await expect(page.locator(".donation-card")).toHaveCount(1);
  const save = page.getByRole("button", { name: /Save Vegetable biryani/ }); await save.click(); await expect(page.getByRole("button", { name: /Unsave Vegetable biryani/ })).toHaveAttribute("aria-pressed", "true");
  await page.getByRole("button", { name: "Filters", exact: true }).click(); await expect(page.getByRole("dialog")).toBeVisible(); await page.keyboard.press("Escape"); await expect(page.getByRole("dialog")).toHaveCount(0);
  await page.getByRole("button", { name: "Map view" }).click(); await expect(page.locator(".leaflet-container")).toBeVisible();
  await page.goto("/"); await page.setViewportSize({ width: 390, height: 844 }); await expect(page.locator(".donation-card")).toHaveCount(3); expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBeTruthy();
  await page.screenshot({ path: "artifacts/refill-overview-mobile.png", fullPage: true }); await page.getByRole("button", { name: "Open navigation" }).click(); await expect(page.locator(".sidebar.mobile-open")).toBeVisible(); await page.getByRole("link", { name: "Impact dashboard", exact: true }).click(); await expect(page.getByRole("heading", { name: "Good things add up." })).toBeVisible(); expect(errors).toEqual([]);
});

test("browser-driven 40-meal journey: create, refresh, reserve 25, pickup, deliver and impact", async ({ page }) => {
  await page.goto("/"); await expect(page.locator(".donation-card")).toHaveCount(3); const baseline = await (await page.request.get("/api/v1/dashboard/impact")).json() as Impact;
  const choose = async (button: RegExp) => { await page.getByRole("button", { name: "Account menu" }).click(); await page.getByRole("button", { name: /Explore a demo account|Switch demo account/ }).click(); await page.getByRole("button", { name: button }).click(); await page.getByRole("button", { name: /Enter demo workspace/ }).click(); await expect(page.getByRole("dialog")).toHaveCount(0); };
  await choose(/Share food Campus Table/); await page.getByRole("button", { name: "Share surplus food", exact: true }).click(); const title = `${prefix} browser vegetable rice`;
  await page.getByLabel(/^Food title/).fill(title); await page.getByLabel(/^Meal portions \*/).fill("40"); await page.getByLabel(/^Description \*/).fill("Fresh vegetable rice portions, packed in clean covered containers for this fictional demo."); await page.getByLabel(/^Storage & handling/).fill("Covered containers. Verify temperature and handling with the kitchen manager."); await page.getByLabel(/^Pickup instructions/).fill("Meet the fictional kitchen manager at the service entrance.");
  const b = await (await page.request.get("/api/v1/bootstrap")).json() as Bootstrap; if (!b.aiConfigured) { await page.getByRole("button", { name: /Polish your description with AI/ }).click(); await expect(page.getByRole("dialog")).toContainText("OpenRouter is not configured"); await page.getByRole("button", { name: "Keep sharing" }).click(); }
  await page.getByRole("button", { name: "Publish donation" }).click(); await expect(page).toHaveURL(/\/donations\/[0-9a-f-]{36}$/); await page.reload(); await expect(page.getByRole("heading", { name: title, exact: true })).toBeVisible();
  await page.getByRole("button", { name: /Find eligible NGO matches/ }).click(); await expect(page.getByRole("dialog")).toContainText("Verified organization"); await page.getByRole("button", { name: "Close dialog" }).click();
  await choose(/Nourish a community Neighbourhood Kitchen/); await page.getByLabel("Meal portions to reserve", { exact: true }).fill("25"); await page.getByRole("button", { name: "Reserve meal portions", exact: true }).click(); await expect(page.locator(".quantity-large")).toContainText("15");
  await choose(/Go the extra mile Maya Patel/); await page.getByRole("link", { name: "Pickups & deliveries", exact: true }).click(); let row = page.locator(".workflow-card").filter({ hasText: title }); await row.getByRole("button", { name: "Record pickup" }).click(); await page.getByRole("button", { name: "Confirm actual quantity" }).click(); await expect(page.getByRole("dialog")).toHaveCount(0);
  await choose(/Nourish a community Neighbourhood Kitchen/); row = page.locator(".workflow-card").filter({ hasText: title }); await row.getByRole("button", { name: "Confirm delivery" }).click(); await page.getByRole("button", { name: "Confirm actual quantity" }).click(); await expect(page.getByRole("dialog")).toHaveCount(0);
  await page.getByRole("link", { name: "Impact dashboard", exact: true }).click(); await expect(page.locator(".impact-big-number")).toContainText(String(baseline.delivered + 25)); await page.reload(); await expect(page.locator(".impact-big-number")).toContainText(String(baseline.delivered + 25));
});
