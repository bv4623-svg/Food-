# Refill — Zero Food Waste AI

A working, role-authorized food redistribution hackathon MVP. The frontend is Next.js/React/TypeScript with Tailwind and reusable accessible components. PostgreSQL is the source of truth. All database access is through Drizzle ORM; the versioned backend is implemented with Next.js server route handlers under `/api/v1`.

## Important architecture difference from the PRD

This deployment uses the provided Next.js + Drizzle runtime, **not Python/FastAPI, SQLAlchemy or Alembic, and not a separately hosted backend application**. API handlers and domain services are server-only modules with a REST boundary. The browser never receives database credentials, API keys, password hashes, session tokens, or verification details. Do not describe this build as having a FastAPI backend or claim the PRD's technology-stack/separate-deployment acceptance criterion is satisfied. A future Python service can implement the same API contract if that criterion is mandatory.

## Run

1. Install dependencies with `npm install`.
2. Copy `.env.example` to `.env` and configure `DATABASE_URL` with a **Node PostgreSQL** URL (`postgresql://...`, not SQLAlchemy's `postgresql+psycopg://...`). Do not commit `.env`.
3. On a fresh database run `npx drizzle-kit migrate` using the checked-in migration, or `npx drizzle-kit push` for an ephemeral demo. Do not migrate an already pushed database without baselining it.
4. Run `npm run dev`. For deployment use `npm run build`, then the hosting platform's production startup.
5. Open `/`. Demo seed data is created once under a PostgreSQL advisory lock when the API is first used. The seed never overwrites existing transactions.

## Demo vs production

`APP_ENV=development` (the default if unset) enables an explicitly labeled **fictional demo workspace**. Click the account menu and choose a demo account: Campus Table (donor), Neighbourhood Kitchen or Hope Pantry (NGO), Maya Patel (assigned volunteer), or the demo administrator. Account switching establishes a real, hashed, database-backed session and does not bypass role, verification or ownership checks. Demo passwords are cryptographically generated and not published.

Set `APP_ENV=production` before publishing a live service. That disables `/auth/demo`, disables seeding and excludes all demo accounts/data from public production queries. Production accounts start unverified. Seeded historical deliveries are fictional **demo impact**, never real-world claims. Registered accounts in a demo environment are also isolated as demo records.

Provision the first production admin through a controlled server-side operator procedure: register a normal account, then use an authorized Drizzle maintenance script to set its one role to admin. There is deliberately no public admin-registration endpoint and no hardcoded production admin password. Only admins can change roles or verification. Do not expose database administration publicly.

## Reproduce the 40-meal workflow (no manual database edits)

1. Choose the Campus Table donor demo. Click **Share surplus food**.
2. Complete all required fields for 40 portions: title, description, dietary/category information, preparation, storage, coordinates/address, collection window, private contact and pickup instructions. Set earliest pickup at or before now and the deadline in the future. Publish, then refresh to verify persistence.
3. The optional AI button makes a real OpenRouter request only when configured. Otherwise it explains that AI is unavailable; manual donation creation remains available.
4. Open **Find eligible NGO matches**. Explanations reflect verification, straight-line distance, available capacity, collection-hour overlap (IST for this Bengaluru MVP) and dietary requirements. The score is deterministic: 50% distance, 30% capacity and 20% time compatibility, not a trained model.
5. Switch to the Neighbourhood Kitchen NGO demo. Find the donation in the marketplace and reserve 25. The detail page shows 15 remaining. A second NGO attempting 16 gets a conflict response, not a success.
6. Switch to the assigned volunteer demo (or the owning donor). Open **Pickups & deliveries** and record actual collection. Uncheck the finish option for an incremental partial pickup; finishing collection releases uncollected reserved portions.
7. Switch to the receiving NGO. Confirm the actual received quantity, optionally in increments. Final deliveries can be less than picked quantities; the difference is not counted as impact.
8. Open **Impact dashboard**, refresh/reload, and confirm that delivered portions—not listed portions—have increased. The CSV export contains actual confirmed delivery records.

To demonstrate 35 delivered of 40: reserve 40, record pickup of 40, and finish delivery with 35. The headline increases by **35**, never 40. The remaining five collected portions are disclosed as not confirmed delivered.

## Integrations

- **PostgreSQL:** required; Drizzle-only access, foreign keys, indexes and quantity checks.
- **OpenRouter:** optional to the core workflow. Requires `OPENROUTER_API_KEY` and `OPENROUTER_MODEL` on the server. Set a model whose endpoint supports JSON-schema outputs. Uses `/api/v1/chat/completions`, `provider.require_parameters`, structured JSON validation and a 15-second timeout. Errors do not change donations or disable transactions. No AI organization approval, safety certification, matching predictions, reservations or confirmations.
- **Email:** disabled unless `EMAIL_PROVIDER_API_KEY`, `EMAIL_FROM_ADDRESS`, and `FRONTEND_URL` are configured. Uses the Resend HTTPS API. Password reset tokens are hashed, expire in 30 minutes, are one-use and invalidate existing sessions. An unavailable/failed provider produces an explicit error, never an 'email sent' claim. Provider acceptance is not a delivery guarantee.
- **Maps:** Leaflet/OpenStreetMap with attribution and stored coordinates. No paid key, geocoding or road routing. Public tile usage is suitable for a small demo; use a compliant hosted tile provider for production traffic. An unavailable map does not block the workflow.
- **Notifications:** persisted in-app notifications; they are not claimed to be outbound email.
- `APP_SECRET_KEY` is listed for compatibility with the requested future backend but is not used by this opaque server-session design. Session entropy comes from cryptographically secure random tokens.

## API / authorization

`/api/v1` includes auth register/login/logout/forgot-password/reset-password/demo, users/me, organizations/me and verification, donations (GET/POST), donations/{id} (GET/PATCH), donations/{id}/reservations, reservations (GET), reservations/{id}/cancel, pickups/{reservation_id}/confirm, deliveries/{reservation_id}/confirm, matches/{donation_id}, dashboard/impact, notifications, uploads/media, reports and admin organizations/accounts/reports/audit.

For this MVP pickup/delivery path IDs are **reservation IDs**. Event IDs are returned after confirmation. Confirmation requests require an `Idempotency-Key` header (8–120 characters). Repeat requests with the same key and quantity return the existing event without increasing impact. Changed quantities under the same key are rejected.

Cookie-authenticated writes require a matching `Origin` header. Clients must use the frontend origin. Cookies are HTTP-only, SameSite=Lax, and Secure in `APP_ENV=production`. Passwords use salted scrypt. Session tokens are stored only as hashes. Public listing responses omit contact information, pickup instructions and verification details; only authorized participants receive private pickup details. Suspended and unverified donors cannot accept reservations. API errors consistently have `{ error: { code, message, fields? } }`.

## Transactional behavior

Reservation operations lock the donation row, then the NGO capacity row; they recheck deadline/remaining quantity and deterministic eligibility inside the transaction. Concurrent requests cannot oversell portions. Cancellation, expiry, pickup and delivery lock the donation before the reservation, preserving lock order. Quantity changes below committed meals are rejected. Listings with active reservations cannot be cancelled until those reservations are resolved. Picked portions cannot be made available again.

`RESERVATION_TTL_MINUTES` defaults to 60 (bounded to 5–360). Holds expire at the earlier of collection deadline or TTL after the later of now/earliest pickup. Expiry maintenance runs lazily before listing/detail/reservation/impact reads and during critical writes; inactive reservations cannot be picked up even before maintenance runs. Add a scheduled worker for proactive production expiry/notifications.

Uploads accept decoded JPEG/PNG files up to 2 MB and 20 megapixels, resize/re-encode to strip metadata, and are stored persistently in PostgreSQL. They cannot contain active HTML/SVG. Uploaded media ownership is checked when attached to a listing.

Account deactivation invalidates sessions and is blocked while active reservations need work. The last administrator cannot self-deactivate. Historical transactions and audit records are retained rather than silently deleted. A production retention policy, legal basis and deletion/anonymization process require operator review before handling real personal data.

## Tests and validation

- `bash -lc 'set -o pipefail; npx next typegen 2>&1 | tee /tmp/next-typegen.log'`
- `bash -lc 'set -o pipefail; npm exec tsc -- --noEmit --pretty false 2>&1 | tee /tmp/tsc.log'`
- `bash -lc 'set -o pipefail; npm run build 2>&1 | tee /tmp/build.log'`
- `npx playwright test` against an already running app (set `BASE_URL` if not localhost:3000).

The Playwright suite exercises persisted creation, matching, 25/15 quantity handling, concurrent oversell prevention, cancellation/expiry, partial pickups/deliveries, role/ownership checks, idempotency, AI unavailability, admin verification, and a browser-driven 40-meal journey. Tests clean up their own test records through Drizzle, not by editing workflow state. Screenshots are stored as test artifacts.

## Remaining production work / honest boundaries

This is a working hackathon MVP, **not a security-audited production release**. Authentication/action rate limits are process-local: deploy a shared Redis/PostgreSQL limiter before running multiple replicas. Configure HTTPS, trusted proxy headers, secret management, TLS/database least-privilege access, backups, retention, email domain validation, provider budgets, and operational monitoring. Organization verification details are manually reviewed, not external registry checks. Contact and transport coordination is in-app; no live fleet routing or SMS is claimed. This project does not claim Pytest tests or a FastAPI/Alembic deployment.

## Media

Hero: custom generated editorial illustration. Food card photography: Pexels contributors Pixel Senses (biryani), Natalia Olivera (bread), Cats Coming (curry), Jack Baghel (salad). Images illustrate explicitly fictional demo listings. Interface font: Manrope, locally served. Icons: Lucide.
